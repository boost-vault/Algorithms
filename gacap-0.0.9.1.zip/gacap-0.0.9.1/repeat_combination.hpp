// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2007, BenBear
// benbearchen at gmail dot com
// 
// Under boost license

// 2007-11-24: Add Herve Bronnimann's repetition functions.
// repeat_combination(first, last, first_value, last_value)

#ifndef __gacap_repeat_combination_hpp_def
#define __gacap_repeat_combination_hpp_def

#include <iterator>
#include <functional>
#include <algorithm>
#include <vector>
#include <cassert>

#include "iterator_proxy.hpp"

namespace gacap
{
  template <typename T,
	    typename Comp = std::less<T> >
  class repeat_combination
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

  private:
    typedef iterator_bridge<T> bridge_type;
    typedef typename std::vector<bridge_type>::const_iterator work_iterator;
    typedef typename std::vector<work_iterator>::iterator item_iterator;
    typedef proxy_compare<T, Comp> compare_type;

  private:
    difference_type _n;

    compare_type _comp;

    std::vector<bridge_type> _iter;
    mutable std::vector<work_iterator> _combi;

  public:
    class iterator:
      public std::iterator<std::bidirectional_iterator_tag, T>
    {
    public:
      typedef T value_type;
      typedef const value_type& const_reference;
      typedef const value_type* const_pointer;
      typedef typename std::vector<work_iterator>::const_iterator item_iterator;

      friend class repeat_combination;
    private:
      item_iterator _item;

      iterator (item_iterator s)
	: _item(s)
      {
      }

    public:
      iterator ()
      {
      }

      iterator&
      operator ++ ()
      {
	++_item;

	return *this;
      }

      iterator
      operator ++ (int)
      {
	iterator iter = *this;
	++*this;
	return iter;
      }

      iterator&
      operator -- ()
      {
	--_item;

	return *this;
      }

      iterator
      operator -- (int)
      {
	iterator iter = *this;
	--*this;
	return iter;
      }

      bool
      operator == (const iterator& rhs) const
      {
	return _item == rhs._item;
      }

      bool
      operator != (const iterator& rhs) const
      {
	return !(*this == rhs);
      }

      const_reference
      operator * () const
      {
	return (**_item).ref();
      }

      const_pointer
      operator -> () const
      {
	return &*this;
      }
    };

  public:
    explicit
    repeat_combination (Comp comp = Comp())
      : _n(0), _comp(comp)
    {
      assign ((T*)0, (T*)0, 0);
    }

    template <typename Iter>
    repeat_combination (Iter first, Iter last, difference_type n, 
			Comp comp = Comp())
      : _n(0), _comp(comp)
    {
      assign (first, last, n);
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, difference_type n)
    {
      _iter.clear();
      _combi.clear();

      for (Iter i = first; i != last; ++i)
	_iter.push_back (bridge_type(i));

      std::sort (_iter.begin(), _iter.end(), _comp);
      _iter.erase (std::unique (_iter.begin(), _iter.end()),
		   _iter.end());

      set_length (n);
    }

    void
    set_length (difference_type n)
    {
      _n = n;
      
      init (true);
    }

    void
    init (bool min = true)
    {
      _unused_ready = false;

      _combi.clear ();

      // if _iter is empty, keep _permu empty always too!!
      if (_iter.empty())
	return;

      work_iterator iter;
      if (min)
	{
	  iter = _iter.begin();
	}
      else
	{
	  iter = _iter.end();
	  --iter;
	}

      _combi.reserve (_n + _iter.size());
      _combi.resize (_n, iter);
    }

    bool
    next ()
    {
      _unused_ready = false;

      if (_iter.empty() || (_n == 0))
	return false;

      // clear the unused_iters
      _combi.resize (_n);

      // g is the greatest element
      work_iterator g = _iter.end();
      --g;
      // if only one element, the sequence don't change
      if (g == _iter.begin())
	return false;

      // ng will be the rightmost position that it's prev position is
      // not the greatest; or ng will equal to _combi.begin() if all
      // positions are the greatest
      item_iterator ng = _combi.end();
      while (ng != _combi.begin())
	{
	  item_iterator p = ng;
	  --p;
	  
	  if (*p == g)
	    ng = p;
	  else
	    break;
	}

      // if all positions is the greatest, it's the last sequence,
      // fill with smallest sequence
      if (ng == _combi.begin())
	{
	  std::fill (_combi.begin(), _combi.end(), 
		     _iter.begin());
	  return false;
	}

      // increase ng's prev position, and fill the rest positions
      item_iterator inc = ng;
      --inc;
      ++*inc;
      std::fill (ng, _combi.end(), *inc);

      return true;
    }

    bool
    prev ()
    {
      _unused_ready = false;

      if (_iter.empty() || (_n == 0))
	return false;

      // clear the unused_iters
      _combi.resize (_n);

      work_iterator g = _iter.end();
      --g;
      if (g == _iter.begin())
	return false;

      // [sg, _combi.end()) will be the greatest `selected' elements
      item_iterator sg = _combi.end();
      --sg;
      while (sg != _combi.begin())
	{
	  item_iterator p = sg;
	  --p;
	  
	  if (*p == *sg)
	    sg = p;
	  else
	    break;
	    
	}

      // *sg == _iter.begin() means that all selected elements are the
      // smallest, change to greatest
      if (*sg == _iter.begin())
	{
	  std::fill (_combi.begin(), _combi.end(), g);
	  
	  return false;
	}

      // decrease the first sg and then fill the rest sg with the
      // greatest element
      --*sg;
      std::fill (++sg, _combi.end(), g);
      
      return true;
    }

    iterator
    begin() const
    {
      return iterator(_combi.begin());
    }

    iterator
    end() const
    {
      if (_iter.empty())
	return begin();
      else
	return iterator(_combi.begin() + _n);
    }

  private:
    mutable bool _unused_ready;

    void
    make_unused () const
    {
      typedef typename std::vector<work_iterator>::const_iterator iterator;
      std::vector<int> f(_iter.size());
      for (iterator i = _combi.begin();
	   i != _combi.end();
	   ++i)
	f[*i - _iter.begin()] = 1;

      for (size_t i = 0; i != f.size(); ++i)
	if (f[i] == 0)
	  _combi.push_back (_iter.begin() + i);
	  
      _unused_ready = true;
    }

  public:
    iterator
    unused_begin() const
    {
      if (!_unused_ready)
	{
	  make_unused ();
	}
      return end();
    }

    iterator
    unused_end() const
    {
      if (!_unused_ready)
	{
	  make_unused ();
	}
      return iterator(_combi.end());
    }
  };

  template <typename BiIter, typename T>
  bool
  next_repeat_combination(BiIter first, BiIter last,
			  T first_value, T last_value)
  {
    BiIter end = last;
    T t = first_value;
    while (end != first)
      {
	BiIter fe = end;
	if (++(*(--fe)) == last_value)
	  end = fe;
	else
	  {
	    t = *fe;
	    break;
	  }
      }
    std::fill (end, last, t);
    return end != first;
  }

  template <typename BiIter, typename T, typename Incrementer>
  bool
  next_repeat_combination(BiIter first, BiIter last, 
			  T first_value, T last_value, 
			  Incrementer increment)
  {
    BiIter end = last;
    T t = first_value;
    while (end != first)
      {
	BiIter fe = end;
	if (increment(*(--fe)) == last_value)
	  end = fe;
	else
	  {
	    t = *fe;
	    break;
	  }
      }
    std::fill (end, last, t);
    return end != first;
  }

  template <typename BiIter, typename T>
  bool
  prev_repeat_combination(BiIter first, BiIter last,
			  T first_value, T last_value)
  {
    if (first == last)
      return false;
    
    BiIter end = last;
    T t = *(--end);
    while (end != first)
      {
	BiIter fe = end;
	if (*(--fe) == t)
	  end = fe;
	else
	  break;
      }
    
    if (t != first_value)
      {
	--*end;
	++end;
      }
    T max = last_value;
    --max;
    std::fill (end, last, max);
    
    return end != first;
  }

  template <typename BiIter, typename T, typename Decrementer>
  bool
  prev_repeat_combination(BiIter first, BiIter last, 
			  T first_value, T last_value, 
			  Decrementer decrement)
  {
    if (first == last)
      return false;
    
    BiIter end = last;
    T t = *(--end);
    while (end != first)
      {
	BiIter fe = end;
	if (*(--fe) == t)
	  end = fe;
	else
	  break;
      }
    
    if (t != first_value)
      {
	decrement(*end);
	++end;
      }
    T max = last_value;
    decrement(max);
    std::fill (end, last, max);
    
    return end != first;
  }

  template <typename BiIter>
  bool
  next_repeat_combination(BiIter first, BiIter last)
  {
    typedef typename std::iterator_traits<BiIter>::value_type value_type;
    if (first == last)
      return false;
    
    BiIter tail = last;
    if (--tail == first)
      return false;
    value_type tv = *tail;
    *tail = 0;
    
    BiIter end = tail;
    while (end != first)
      {
	BiIter fe = end;
	if (*(--fe) == 0)
	  end = fe;
	else
	  break;
      }
    if (end == first)
      {
	*end = *end + tv;
        return false;
      }
    
    BiIter dec = end;
    --*--dec;
    *end = tv + 1;
    return true;
  }
  
  template <class BiIter>
  bool
  prev_repeat_combination(BiIter first, BiIter last)
  {
    typedef typename std::iterator_traits<BiIter>::value_type value_type;
    if (first == last)
      return false;

    BiIter tail = last;
    if (--tail == first)
      return false;
    
    BiIter end = last;
    while (end != first)
      {
	BiIter fe = end;
	if (*(--fe) == 0)
	  end = fe;
	else
	  break;
      }
    
    if (end != first)
      --end;
    value_type tv = *end;
    *end = 0;
    if (end != first)
      {
	BiIter fe = end;
	++*--fe;
	--tv;
      }
    
    *tail = tv;
    
    return end != first;
  }



  template <typename T,
	    typename Comp = std::less<T> >
  class repeat_combination_ex
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

  private:
    typedef iterator_bridge<T> bridge_type;
    typedef typename std::vector<bridge_type>::const_iterator work_iterator;
    typedef typename std::vector<work_iterator>::iterator item_iterator;
    typedef proxy_compare<T, Comp> compare_type;

  public:
    class iterator:
      public std::iterator<std::bidirectional_iterator_tag, T>
    {
    public:
      typedef T value_type;
      typedef const value_type& const_reference;
      typedef const value_type* const_pointer;
      typedef typename std::vector<work_iterator>::const_iterator item_iterator;

    private:
      friend class repeat_combination_ex;

      item_iterator _item;

      iterator (item_iterator item)
	: _item(item)
      {
      }

    public:
      iterator ()
      {
      }

      iterator&
      operator ++ ()
      {
	++_item;

	return *this;
      }

      iterator
      operator ++ (int)
      {
	iterator iter = *this;
	++*this;
	return iter;
      }

      iterator&
      operator -- ()
      {
	--_item;

	return *this;
      }

      iterator
      operator -- (int)
      {
	iterator iter = *this;
	--*this;
	return iter;
      }

      bool
      operator == (const iterator& rhs) const
      {
	return _item == rhs._item;
      }

      bool
      operator != (const iterator& rhs) const
      {
	return !(*this == rhs);
      }

      const_reference
      operator * () const
      {
	return (**_item).ref();
      }

      const_pointer
      operator -> () const
      {
	return &**this;
      }
    };

  private:
    std::vector<bridge_type> _iter;
    mutable std::vector<work_iterator> _permu;

    compare_type _comp;

    difference_type _len;

    difference_type _min_len;
    difference_type _max_len;

  public:
    explicit
    repeat_combination_ex (Comp comp = Comp())
      : _comp(comp)
    {
      assign ((T*)0, (T*)0, 0, 0);
    }

    template <typename Iter>
    repeat_combination_ex (Iter first, Iter last,
			   difference_type min_len, 
			   difference_type max_len,
			   Comp comp = Comp())
      : _comp(comp)
    {
      assign (first, last, min_len, max_len);
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, 
	    difference_type min_len, difference_type max_len)
    {
      _iter.clear();
      _permu.clear();

      for (Iter i = first; i != last; ++i)
	_iter.push_back (bridge_type(i));

      std::sort (_iter.begin(), _iter.end(), _comp);
      _iter.erase (std::unique (_iter.begin(), _iter.end()),
		   _iter.end());

      set_length (min_len, max_len);
    }

    void
    set_length (difference_type min_len, difference_type max_len)
    {
      assert ((min_len >= 0) && (max_len >= min_len));

      _min_len = min_len;
      _max_len = max_len;

      init (true);
    }

    void
    init (bool min)
    {
      _unused_ready = false;

      _len = 0;
      _permu.clear ();

      // if _iter is empty, keep _permu empty always too!!
      if (_iter.empty())
	return;

      work_iterator iter;
      if (min)
	{
	  iter = _iter.begin();
	}
      else
	{
	  iter = _iter.end();
	  --iter;
	}

      _permu.reserve (_max_len + _iter.size());

      _len = (min ? _min_len : _max_len);
      _permu.resize (_len, iter);
    }

  private:
    item_iterator
    find_right_same (item_iterator first, 
		     item_iterator last)
    {
      if (first == last)
	return last;
      item_iterator e = last;
      while (--e != first)
	{
	  item_iterator f = e;
	  if (*--f != *e)
	    break;
	}
      return e;
    }

  public:
    bool
    next ()
    {
      _unused_ready = false;

      if (_iter.empty() || (_max_len == 0))
	return false;

      _permu.resize (_len);
      
      work_iterator ws = _iter.begin();
      work_iterator wg = _iter.end();
      --wg;
      
      if (_len != _max_len)
	{
	  if (_len == 0)
	    _permu.push_back (ws);
	  else
	    _permu.push_back (_permu.back());
	  ++_len;
	  return true;
	}

      item_iterator first = _permu.begin();
      item_iterator last = _permu.end();
      item_iterator e = last;
      --e;
      if (*e != wg)
	{
	  ++*e;
	  return true;
	}
      item_iterator g = find_right_same (first, last);
      if (g == first)
	{
	  init (true);
	  return false;
	}

      item_iterator inc = g;
      ++*--inc;

      difference_type len = std::distance (first, g);
      _permu.resize (len);
      if (len < _min_len)
	{
	  len = _min_len;
	  _permu.resize (len, *inc);
	}

      _len = len;

      return true;
    }

    bool
    prev ()
    {
      _unused_ready = false;

      if (_iter.empty() || (_max_len == 0))
	return false;

      _permu.resize (_len);
      
      if (_len == 0)
	{
	  init (false);
	  return false;
	}

      work_iterator ws = _iter.begin();
      work_iterator wg = _iter.end();
      --wg;

      item_iterator first = _permu.begin();
      item_iterator last = _permu.end();
      item_iterator e = last;
      --e;

      item_iterator r = find_right_same (first, last);
      if (((*r == ws) || (r != e)) && (_len != _min_len))
	{
	  --_len;
	  _permu.pop_back ();
	  return true;
	}

      if (*r != ws)
	{
	  --*r;
	  difference_type len = std::distance (first, r) + 1;
	  if (len != _max_len)
	    {
	      _permu.resize (len);
	      len = _max_len;
	      _permu.resize (len, wg);

	      _len = len;
	    }
	  return true;
	}

      if (_len != _min_len)
	{
	  --_len;
	  _permu.pop_back ();
	  return true;
	}

      init (false);
      return false;
    }

    iterator
    begin() const
    {
      return iterator(_permu.begin());
    }
    iterator
    end() const
    {
      return iterator(_permu.begin() + _len);
    }

  private:
    mutable bool _unused_ready;

    void
    make_unused () const
    {
      typedef typename std::vector<work_iterator>::const_iterator iterator;
      std::vector<int> f(_iter.size());
      for (iterator i = _permu.begin();
	   i != _permu.end();
	   ++i)
	f[*i - _iter.begin()] = 1;

      for (size_t i = 0; i != f.size(); ++i)
	if (f[i] == 0)
	  _permu.push_back (_iter.begin() + i);
	  
      _unused_ready = true;
    }

  public:
    iterator
    unused_begin() const
    {
      if (!_unused_ready)
	{
	  make_unused ();
	}
      return end();
    }

    iterator
    unused_end() const
    {
      if (!_unused_ready)
	{
	  make_unused ();
	}
      return iterator(_permu.end());
    }
  };
}

#endif
