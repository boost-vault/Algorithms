// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2007, BenBear
// benbearchen at gmail dot com
//
// Under boost license

#include "combination.hpp"
#include "permutation.hpp"
#include "repeat_permutation.hpp"
#include "repeat_combination.hpp"

namespace gacap
{
  template <bool order, bool repeat, typename T, typename Comp = std::less<T> >
  class acap;

  template <typename T, typename Comp>
  class acap<false, false, T, Comp>: public combination<T, Comp>
  {
    typedef typename combination<T, Comp>::difference_type difference_type;
  public:
    acap (Comp comp = Comp())
      : combination<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap (Iter first, Iter last, difference_type n,
	  Comp comp = Comp())
      : combination<T, Comp>(first, last, n, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap<true, false, T, Comp>: public permutation<T, Comp>
  {
    typedef typename permutation<T, Comp>::difference_type difference_type;
  public:
    acap (Comp comp = Comp())
      : permutation<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap (Iter first, Iter last, difference_type n,
	  Comp comp = Comp())
      : permutation<T, Comp>(first, last, n, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap<false, true, T, Comp>: public repeat_combination<T, Comp>
  {
    typedef typename repeat_combination<T, Comp>::difference_type difference_type;
  public:
    acap (Comp comp = Comp())
      : repeat_combination<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap (Iter first, Iter last, difference_type n,
	  Comp comp = Comp())
      : repeat_combination<T, Comp>(first, last, n, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap<true, true, T, Comp>: public repeat_permutation<T, Comp>
  {
    typedef typename repeat_permutation<T, Comp>::difference_type difference_type;
  public:
    acap (Comp comp = Comp())
      : repeat_permutation<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap (Iter first, Iter last, difference_type n,
	  Comp comp = Comp())
      : repeat_permutation<T, Comp>(first, last, n, comp)
    {
    }
  };



  template <bool order, bool repeat, typename T, typename Comp = std::less<T> >
  class acap_ex;

  template <typename T, typename Comp>
  class acap_ex<false, false, T, Comp>: public combination_ex<T, Comp>
  {
    typedef typename combination_ex<T, Comp>::difference_type difference_type;
  public:
    acap_ex (Comp comp = Comp())
      : combination_ex<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap_ex (Iter first, Iter last, 
	     difference_type min_len, difference_type max_len,
	     Comp comp = Comp())
      : combination_ex<T, Comp>(first, last, min_len, max_len, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap_ex<true, false, T, Comp>: public permutation_ex<T, Comp>
  {
    typedef typename permutation_ex<T, Comp>::difference_type difference_type;
  public:
    acap_ex (Comp comp = Comp())
      : permutation_ex<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap_ex (Iter first, Iter last, 
	     difference_type min_len, difference_type max_len,
	     Comp comp = Comp())
      : permutation_ex<T, Comp>(first, last, min_len, max_len, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap_ex<false, true, T, Comp>: public repeat_combination_ex<T, Comp>
  {
    typedef typename repeat_combination_ex<T, Comp>::difference_type difference_type;
  public:
    acap_ex (Comp comp = Comp())
      : repeat_combination_ex<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap_ex (Iter first, Iter last, 
	     difference_type min_len, difference_type max_len,
	     Comp comp = Comp())
      : repeat_combination_ex<T, Comp>(first, last, min_len, max_len, comp)
    {
    }
  };

  template <typename T, typename Comp>
  class acap_ex<true, true, T, Comp>: public repeat_permutation_ex<T, Comp>
  {
    typedef typename repeat_permutation_ex<T, Comp>::difference_type difference_type;
  public:
    acap_ex (Comp comp = Comp())
      : repeat_permutation_ex<T, Comp>(comp)
    {
    }

    template <typename Iter>
    acap_ex (Iter first, Iter last, 
	     difference_type min_len, difference_type max_len,
	     Comp comp = Comp())
      : repeat_permutation_ex<T, Comp>(first, last, min_len, max_len, comp)
    {
    }
  };
}
