// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2007, BenBear
// benbearchen at gmail dot com
// 
// Under boost license

#ifndef __gacap_permutation_hpp_def
#define __gacap_permutation_hpp_def

#include <algorithm>
#include <iterator>
#include <vector>
#include <functional>
#include <cassert>

#include "iterator_proxy.hpp"
#include "combi_utility.hpp"

namespace gacap
{
  template <typename BiIter>
  void
  init_permutation (BiIter first, BiIter middle, BiIter last, 
		    bool min = true)
  {
    __sort_combination (first, middle);
    __sort_combination (middle, last);
    if (min)
      __twice_merge (first, middle, middle, last);
    else
      {
	__twice_merge (middle, last, first, middle);
	std::reverse (first, middle);
      }
  }

  template <typename BiIter, typename Comp>
  void
  init_permutation (BiIter first, BiIter middle, BiIter last, 
		    bool min, Comp comp)
  {
    __sort_combination (first, middle, comp);
    __sort_combination (middle, last, comp);
    if (min)
      __twice_merge (first, middle, middle, last, comp);
    else
      {
	__twice_merge (middle, last, first, middle, comp);
	std::reverse (first, middle);
      }
  }

  template <typename BiIter>
  void
  adjust_permutation (BiIter first, BiIter middle, BiIter last)
  {
    __sort_combination (middle, last);
  }

  template <typename BiIter, typename Comp>
  void
  adjust_permutation (BiIter first, BiIter middle, BiIter last,
		      Comp comp)
  {
    __sort_combination (middle, last, comp);
  }

  template <typename BiIter>
  inline bool
  next_permutation (BiIter first, BiIter middle, BiIter last)
  {
    if (first == middle)
      return false;

    std::reverse (middle, last);
    return std::next_permutation (first, last);
  }

  template <typename BiIter, typename Comp>
  inline bool
  next_permutation (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    if (first == middle)
      return false;

    std::reverse (middle, last);
    return std::next_permutation (first, last, comp);
  }

  template <typename BiIter>
  inline bool 
  prev_permutation (BiIter first, BiIter middle, BiIter last)
  {
    if (first == middle)
      return false;

    bool ret = std::prev_permutation (first, last);
    std::reverse (middle, last);

    return ret;
  }

  template <typename BiIter, typename Comp>
  inline bool 
  prev_permutation (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    if (first == middle)
      return false;

    bool ret = std::prev_permutation (first, last, comp);
    std::reverse (middle, last);

    return ret;
  }

  template <typename BiIter>
  inline bool
  next_partial_permutation (BiIter first, BiIter middle, BiIter last)
  {
    return next_permutation (first, middle, last);
  }

  template <typename BiIter, typename Comp>
  inline bool
  next_partial_permutation (BiIter first, BiIter middle, BiIter last, 
			    Comp comp)
  {
    return next_permutation (first, middle, last, comp);
  }

  template <typename BiIter>
  inline bool 
  prev_partial_permutation (BiIter first, BiIter middle, BiIter last)
  {
    return prev_permutation (first, middle, last);
  }

  template <typename BiIter, typename Comp>
  inline bool 
  prev_partial_permutation (BiIter first, BiIter middle, BiIter last, 
			    Comp comp)
  {
    return prev_permutation (first, middle, last, comp);
  }

  template <typename BiIter, 
	    typename Comp = std::less<typename std::iterator_traits<BiIter>::value_type> >
  class permutation_inplace
  {
  public:
    typedef typename std::iterator_traits<BiIter>::value_type value_type;
    typedef typename std::iterator_traits<BiIter>::difference_type difference_type;
    typedef typename std::vector<value_type>::iterator buffer_iterator;

    typedef proxy_const_iterator<BiIter> iterator;

  private:
    BiIter _first;
    BiIter _middle;
    BiIter _last;

    Comp _comp;
  public:
    explicit
    permutation_inplace (Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (BiIter(), BiIter(), 0);
    }

    permutation_inplace (BiIter first, BiIter middle, BiIter last,
			 Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (first, middle, last);
    }

    permutation_inplace (BiIter first, BiIter last, difference_type m, 
			 Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (first, last, m);
    }
  public:
    void
    assign (BiIter first, BiIter middle, BiIter last)
    {
      assign (first, last, std::distance (first, middle));
    }

    void
    assign (BiIter first, BiIter last, difference_type m)
    {
      _first = first;
      _last = last;

      set_length (m);
    }

    void
    set_length (difference_type m)
    {
      difference_type len = std::distance (_first, _last);
      if (m > len)
	m = len;
      
      _middle = _first;
      std::advance (_middle, m);

      adjust ();
    }

    void
    init (bool min)
    {
      init_permutation (_first, _middle, _last, min, 
			_comp);
    }

  private:
    void
    adjust ()
    {
      adjust_permutation (_first, _middle, _last, 
			  _comp);
    }

  public:
    bool
    next ()
    {
      return next_permutation (_first, _middle, _last, 
			       _comp);
    }

    bool
    prev ()
    {
      return prev_permutation (_first, _middle, _last, 
			       _comp);
    }

    iterator
    begin() const
    {
      return iterator(_first);
    }
    iterator
    end() const
    {
      return iterator(_middle);
    }
    iterator
    unused_begin() const
    {
      return iterator(_middle);
    }
    iterator
    unused_end() const
    {
      return iterator(_last);
    }
  };

  template <typename T, 
	    typename Comp = std::less<T> >
  class permutation
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

    typedef iterator_bridge<T> bridge_type;
    typedef bridge_type* inner_iterator;
    typedef proxy_compare<T, Comp> compare_type;
    typedef proxy_iterator<T> iterator;

  private:
    permutation_inplace<inner_iterator, compare_type> _permu;
    std::vector<bridge_type> _iterators;

  public:
    explicit
    permutation (Comp comp = Comp())
      : _permu(compare_type(comp))
    {
    }

    template <typename Iter>
    permutation (Iter first, Iter middle, Iter last, 
		 Comp comp = Comp())
      : _permu(compare_type(comp))
    {
      assign (first, middle, last);
    }

    template <typename Iter>
    permutation (Iter first, Iter last, difference_type m, 
		 Comp comp = Comp())
      : _permu(compare_type(comp))
    {
      assign (first, last, m);
    }
  public:
    template <typename Iter>
    void
    assign (Iter first, Iter middle, Iter last)
    {
      assign (first, last, std::distance (first, middle));
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, difference_type m)
    {
      _iterators.clear ();
      _iterators.reserve (std::distance (first, last));
      for (Iter i = first; i != last; ++i)
	_iterators.push_back (bridge_type(i));

      inner_iterator _first = &_iterators.front();
      inner_iterator _last = _first + _iterators.size();
      
      _permu.assign (_first, _last, m);
    }

    void
    set_length (difference_type m)
    {
      _permu.set_length (m);
    }

    void
    init (bool min)
    {
      _permu.init (min);
    }

  public:
    bool
    next ()
    {
      return _permu.next();
    }

    bool
    prev ()
    {
      return _permu.prev ();
    }

    iterator
    begin() const
    {
      return iterator(_permu.begin());
    }
    iterator
    end() const
    {
      return iterator(_permu.end());
    }
    iterator
    unused_begin() const
    {
      return iterator(_permu.unused_begin());
    }
    iterator
    unused_end() const
    {
      return iterator(_permu.unused_end());
    }
  };



  template <typename T,
	    typename Comp = std::less<T> >
  class permutation_ex
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

  private:
    typedef iterator_bridge<T> bridge_type;
    typedef typename std::vector<bridge_type>::iterator iter;
    typedef proxy_compare<T, Comp> compare_type;

  public:
    class iterator:
      public std::iterator<std::bidirectional_iterator_tag, T>
    {
    public:
      typedef T value_type;
      typedef const value_type& const_reference;
      typedef const value_type* const_pointer;
      typedef typename std::vector<bridge_type>::const_iterator item_iterator;

    private:
      friend class permutation_ex;

      item_iterator _item;

      iterator (item_iterator item)
	: _item(item)
      {
      }

    public:
      iterator ()
      {
      }

      iterator&
      operator ++ ()
      {
	++_item;

	return *this;
      }

      iterator
      operator ++ (int)
      {
	iterator iter = *this;
	++*this;
	return iter;
      }

      iterator&
      operator -- ()
      {
	--_item;

	return *this;
      }

      iterator
      operator -- (int)
      {
	iterator iter = *this;
	--*this;
	return iter;
      }

      bool
      operator == (const iterator& rhs) const
      {
	return _item == rhs._item;
      }

      bool
      operator != (const iterator& rhs) const
      {
	return !(*this == rhs);
      }

      const_reference
      operator * () const
      {
	return (*_item).ref();
      }

      const_pointer
      operator -> () const
      {
	return &**this;
      }
    };

  private:
    std::vector<bridge_type> _values;

    compare_type _comp;

    difference_type _len;

    difference_type _min_len;
    difference_type _max_len;

  public:
    explicit
    permutation_ex (Comp comp = Comp())
      : _comp(comp)
    {
      assign ((T*)0, (T*)0, 0, 0);
    }

    template <typename Iter>
    permutation_ex (Iter first, Iter last,
		    difference_type min_len, 
		    difference_type max_len,
		    Comp comp = Comp())
      : _comp(comp)
    {
      assign (first, last, min_len, max_len);
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, 
	    difference_type min_len, 
	    difference_type max_len)
    {
      _values.clear ();
      _values.reserve (std::distance (first, last));
      for (Iter i = first; i != last; ++i)
	_values.push_back (bridge_type(i));
      
      set_length (min_len, max_len);
    }

    void
    set_length (difference_type min_len, 
		difference_type max_len)
    {
      assert ((min_len >= 0) && (max_len >= min_len));

      if (max_len > _values.size())
	max_len = _values.size();

      _min_len = min_len;
      _max_len = max_len;

      init (true);
    }

    void
    init (bool min)
    {
      if (min)
	_len = _min_len;
      else
	_len = _max_len;

      init_permutation (_values.begin(), _values.begin() + _len, 
			_values.end(), min, _comp);
    }

    bool
    next ()
    {
      if (_values.empty())
	return false;

      if (_len != _max_len)
	{
	  ++_len;
	  return true;
	}

      if (_len == 0)
	return false;

      if (_values.size() == 1)
	{
	  _len = _min_len;
	  return false;
	}

      iter first = _values.begin();
      iter middle = first + _max_len;
      iter last = _values.end();

      // reverse [middle, last), ready to work state
      std::reverse (middle, last);
      
      // find the rightest increase-able element
      iter inc = last - 1;
      while (inc != first)
	{
	  iter f = inc - 1;
	  if (_comp(*f, *inc))
	    break;

	  inc = f;
	}
      
      if (inc == first)
	{
	  // finish??
	  _len = _min_len;
	  std::reverse (first, last);
	  
	  return false;
	}

      difference_type inc_len = inc - first;
      --inc;

      iter dec = last - 1;
      while (!_comp(*inc, *dec))
	--dec;

      std::iter_swap (inc, dec);
      std::reverse (inc + 1, last);

      if (inc_len > _min_len)
	_len = inc_len;
      else
	_len = _min_len;

      return true;
    }

    bool
    prev ()
    {
      // if the rightest selected element can't be decrease, and the
      // _len is greater than _min_len, --_len, and return true

      // else if can decrease hole range, decrease it, and set _len to
      // _max_len

      // else, return false

      if (_values.empty())
	return false;

      if (_len == 0)
	{
	  init (false);
	  return false;
	}

      iter first = _values.begin();
      iter middle = first + _len;
      iter last = _values.end();

      if (((middle == last) || !_comp(*middle, *(middle - 1)))
	  && (_len > _min_len))
	{
	  --_len;
	  return true;
	}

      iter small = middle;
      if (middle == last)
	--small;

      while (small != first)
	{
	  iter big = small - 1;
	  if (_comp(*small, *big))
	    break;

	  small = big;
	}

      if (small == first)
	{
	  init (false);
	  return false;
	}
      
      iter big = small - 1;
      iter pos = std::lower_bound (small, last, *big, _comp) - 1;
      std::iter_swap (big, pos);
      std::reverse (small, last);
      _len = _max_len;
      std::reverse (first + _len, last);
	  
      return true;
    }

    iterator
    begin() const
    {
      return iterator(_values.begin());
    }
    iterator
    end() const
    {
      return iterator(_values.begin() + _len);
    }
    iterator
    unused_begin() const
    {
      return end();
    }
    iterator
    unused_end() const
    {
      return iterator(_values.end());
    }
  };
}

#endif
