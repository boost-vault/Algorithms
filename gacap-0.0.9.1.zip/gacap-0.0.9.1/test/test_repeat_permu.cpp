#include <iostream>
#include <functional>
#include <vector>
using namespace std;

#include "../repeat_permutation.hpp"
#include "../permutation.hpp"
#include "compare.hpp"

int main ()
{
  int a[] = {1, 2, 3, 4};

  typedef gacap::repeat_permutation<int> repeat_permutation;
  typedef gacap::permutation<int> permutation;
  typedef repeat_permutation::iterator iterator;
  repeat_permutation permu(a, a + 4, 0);
  
  for (int n = 0; n < 5; ++n)
    {
      try
	{
	  permu.set_length (n);

	  int count_next = test_picker_next_count (permu);
	  cout << "count of next selection: " << count_next << endl;

	  int count_prev = test_picker_prev_count (permu);
	  cout << "count of prev selection: " << count_prev << endl;

	  cout << "test count of selection: "
	       << ((count_prev == count_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;


	  vector<int> tmp;
	  for (int i = 0; i < n; ++i)
	    tmp.insert (tmp.end(), a, a + 4);
	  permutation test_combi(tmp.begin(),
				 tmp.begin() + n,
				 tmp.end());

	  int combi_next = test_picker_next_count (test_combi);
	  cout << "count of next combination: " << combi_next << endl;

	  int combi_prev = test_picker_prev_count (test_combi);
	  cout << "count of prev combination: " << combi_prev << endl;

	  cout << "test count of combination: "
	       << ((combi_prev == combi_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;

	  cout << "selection vs combination: "
	       << ((combi_next == count_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;

	  try
	    {
	      if (test_two_picker_equal (permu, test_combi))
		cout << "permu equal test_combi" << endl;
	    }
	  catch (const char* err)
	    {
	      cout << "permu don't equal test_combi: exception: " << endl;
	      cout << err << endl;
	    }

	  cout << endl << endl;
	}
      catch (const char* err)
	{
	  cout << "exception::::" << endl;
	  cout << err << endl;
	}
    }

  cout << "press ENTER to continue..." << endl;
  cin.get();

  permu.set_length(3);
  do
    {
      for (iterator i = permu.begin(); i != permu.end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (permu.next ());
  cout << "------------------" << endl;
  permu.prev ();
  do
    {
      for (iterator i = permu.begin(); i != permu.end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (permu.prev ());

  cout << "press ENTER to continue..." << endl;
  cin.get();

  permu.set_length (2);
  permu.prev ();
  do
    {
      for (iterator i = permu.begin(); i != permu.unused_end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (permu.prev ());

  cout << "press ENTER to exit..." << endl;
  cin.get();

  // test for function
  {
    typedef gacap::repeat_permutation<int> t;

    t tb(a, a + 5, 3);
    t();

    tb.assign (a, a + 5, 3);
  }

  return 0;
}
