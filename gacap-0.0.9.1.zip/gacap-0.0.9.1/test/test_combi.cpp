#include "../combination.hpp"
using namespace gacap;

#include "compare.hpp"

#include <iostream>
#include <cstring>
#include <functional>
using namespace std;

int main()
{
  int a[] = {1, 2, 3, 4, 5};
  int b[] = {1, 2, 3, 4, 5};

  gacap::combination_inplace<int*> combi_a (a, a + 3, a + 5);
  gacap::combination<int> combi_b (b, b + 3, b + 5);

  try
    {
      if (test_two_picker_equal (combi_a, combi_b))
	cout << "combi_a is equal combi_b" << endl;
    }
  catch (const char* err)
    {
      cout << "exception: " << err << endl;
    }
  
  int c[][5] = {{1, 2, 3, 4, 5},
		{1, 1, 3, 4, 5},
		{1, 2, 2, 3, 3},
		{1, 1, 1, 1, 1},
		{1, 3, 3, 3, 3},
		{1, 1, 2, 3, 3},
		{1, 1, 5, 5, 5}};

  for (int i = 0; i < sizeof(c) / sizeof(c[0]); ++i)
    {
      try
	{
	  cout << i << endl;
	  gacap::combination<int> c1;
	  c1.assign (c[i], c[i] + 5, 2);
	  c1.set_length (2);
	  gacap::combination<int> c2(c[i], c[i] + 5, 2);
	  c2.set_length (2);
	  gacap::combination<int> c3(c[i], c[i] + 5, 2);

	  test_two_picker_equal (c1, c2);
	  test_two_picker_equal (c2, c3);
	}
      catch (const char* err)
	{
	  cout << "exception: " << err << endl;
	}
    }
  cout << "press ENTER to exit...";
  cin.get ();

  // test for function
  {
    gacap::combination_inplace<int*> ta(a, a + 5, 3);
    gacap::combination<int> tb(b, b + 5, 3);
    gacap::combination_inplace<int*>(a, a + 3, a + 5, less<int>());
    gacap::combination<int>(b, b + 3, a + 5, less<int>());
    gacap::combination_inplace<int*>();
    gacap::combination<int>();

    ta.assign (a, a + 5, 3);
    ta.assign (a, a + 3, a + 5);

    tb.assign (a, a + 5, 3);
    tb.assign (a, a + 3, a + 5);
  }
}

