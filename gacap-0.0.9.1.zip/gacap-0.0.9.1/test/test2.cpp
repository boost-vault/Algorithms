#include "../combination.hpp"
using namespace gacap;

#include "./compare.hpp"

#include <iostream>
#include <cstring>
using namespace std;

void
my_throw (const char* msg, int line)
{
  size_t len = strlen (msg);
  char* str = new char[len + 20];
  strncpy (str, msg, len);
  sprintf (str + len, " at line: %d", line);
  throw (const char*)str;
}

template <typename Iter>
int
get_number1 (Iter first, Iter middle, Iter last)
{
  int cn = 0;
  init_combination(first, middle, last, true);

  test_sequence_serial<Iter> nfm(true);
  do
    {
      if (!test_sequence_grow (first, middle))
	my_throw ("test order failed", __LINE__);
      nfm.push_sequence (first, middle);
      if (!test_sequence_grow (middle, last))
	my_throw ("test order failed", __LINE__);

      ++cn;
    }
  while (next_combination (first, middle, last));

  int cp = 0;
  init_combination (first, middle, last, false);
  
  test_sequence_serial<Iter> pfm(false);
  do
    {
      if (!test_sequence_grow (first, middle))
	my_throw ("test order failed", __LINE__);
      pfm.push_sequence (first, middle);
      if (!test_sequence_grow (middle, last))
	my_throw ("test order failed", __LINE__);

      ++cp;
    }
  while (prev_combination (first, middle, last));
  
  if (cn != cp)
    my_throw ("next_combination != prev_combination", __LINE__);

  return cn;
}

template <typename Iter>
int
get_number2 (Iter first, Iter middle, Iter last)
{
  int cn = 0;
  typedef combination_inplace<Iter> combination_type;
  typedef typename combination_type::iterator iterator; 
  combination_type combi (first, middle, last);
  combi.init (true);

  test_sequence_serial<iterator> nfm(true);
  do
    {
      if (!test_sequence_grow (combi.begin(), combi.end()))
	my_throw ("test order failed", __LINE__);
      nfm.push_sequence (combi.begin(), combi.end());
      if (!test_sequence_grow (combi.unused_begin(), combi.unused_end()))
	my_throw ("test order failed", __LINE__);

      ++cn;
    }
  while (combi.next ());

  int cp = 0;
  combi.init (false);
  
  test_sequence_serial<iterator> pfm(false);
  do
    {
      if (!test_sequence_grow (combi.begin(), combi.end()))
	my_throw ("test order failed", __LINE__);
      pfm.push_sequence (combi.begin(), combi.end());
      if (!test_sequence_grow (combi.unused_begin(), combi.unused_end()))
	my_throw ("test order failed", __LINE__);

      ++cp;
    }
  while (combi.prev ());
  
  if (cn != cp)
    my_throw ("next_combination != prev_combination", __LINE__);

  return cn;
}

template <typename Iter>
int
get_number3 (Iter first, Iter middle, Iter last)
{
  int cn = 0;
  typedef typename std::iterator_traits<Iter>::value_type value_type;
  typedef combination<value_type, std::greater<value_type> > combination_type;
  typedef typename combination_type::iterator iterator;

  std::greater<value_type> comp;
  combination_type combi (first, middle, last, comp);
  combi.init (true);

  test_sequence_serial<iterator, std::greater<value_type> > nfm(true, comp);
  do
    {
      if (!test_sequence_grow (combi.begin(), combi.end(), comp))
	my_throw ("test order failed", __LINE__);
      nfm.push_sequence (combi.begin(), combi.end());
      if (!test_sequence_grow (combi.unused_begin(), combi.unused_end(), comp))
	my_throw ("test order failed", __LINE__);

      ++cn;
    }
  while (combi.next ());

  int cp = 0;
  combi.init (false);
  
  test_sequence_serial<iterator, std::greater<value_type> > pfm(false, comp);
  do
    {
      if (!test_sequence_grow (combi.begin(), combi.end(), comp))
	my_throw ("test order failed", __LINE__);
      pfm.push_sequence (combi.begin(), combi.end());
      if (!test_sequence_grow (combi.unused_begin(), combi.unused_end(), comp))
	my_throw ("test order failed", __LINE__);

      ++cp;
    }
  while (combi.prev ());
  
  if (cn != cp)
    my_throw ("next_combination != prev_combination", __LINE__);

  return cn;
}

template <typename Iter>
int
get_number4 (Iter first, Iter middle, Iter last)
{
  int cn = 0;
  typedef typename std::iterator_traits<Iter>::value_type value_type;
  std::greater<value_type> comp;
  init_combination(first, middle, last, true, comp);

  test_sequence_serial<Iter, std::greater<value_type> > nfm(true, comp);
  do
    {
      if (!test_sequence_grow (first, middle, comp))
	my_throw ("test order failed", __LINE__);
      nfm.push_sequence (first, middle);
      if (!test_sequence_grow (middle, last, comp))
	my_throw ("test order failed", __LINE__);

      ++cn;
    }
  while (next_combination (first, middle, last, comp));

  int cp = 0;
  init_combination (first, middle, last, false, comp);
  
  test_sequence_serial<Iter, std::greater<value_type> > pfm(false, comp);
  do
    {
      if (!test_sequence_grow (first, middle, comp))
	my_throw ("test order failed", __LINE__);
      pfm.push_sequence (first, middle);
      if (!test_sequence_grow (middle, last, comp))
	my_throw ("test order failed", __LINE__);

      ++cp;
    }
  while (prev_combination (first, middle, last, comp));
  
  if (cn != cp)
    my_throw ("next_combination != prev_combination", __LINE__);

  return cn;
}

int main ()
{
  try
    {
      int a[5] = {1, 2, 3, 4, 5};
      int g1 = get_number1 (a, a + 2, a + 5); cout << "g1 ok" << endl;
      int g2 = get_number2 (a, a + 2, a + 5); cout << "g2 ok" << endl;
      int g3 = get_number3 (a, a + 2, a + 5); cout << "g3 ok" << endl;
      int g4 = get_number4 (a, a + 2, a + 5); cout << "g4 ok" << endl;
      int t = test_get_combi_count (a, a + 2, a + 5);

      if (g1 != t)
	{
	  cout << g1 << " != " << t << endl;
	  my_throw ("get number 1 != test get number", __LINE__);
	}
      if (g2 != t)
	{
	  cout << g2 << " != " << t << endl;
	  my_throw ("get number 2 != test get number", __LINE__);
	}
      if (g3 != t)
	{
	  cout << g3 << " != " << t << endl;
	  my_throw ("get number 3 != test get number", __LINE__);
	}
      if (g4 != t)
	{
	  cout << g4 << " != " << t << endl;
	  my_throw ("get number 4 != test get number", __LINE__);
	}
      cout << "test is ok!" << endl;
    }
  catch (const char* except)
    {
      cout << "Exception:"
	   << except
	   << endl;
    }
}
