#include "../permutation.hpp"
using namespace gacap;

#include "./compare.hpp"

#include <iostream>
#include <cstring>
#include <functional>
using namespace std;

int main()
{
  typedef permutation<int> permu;
  typedef permu::iterator iterator;

  int a[] = {1, 1, 3, 4, 5, 6};
  int b[] = {1, 1, 3, 4, 5, 6};
  permu oc(a, a + 6, 3);
  permu oc2(a, a + 6, 3);
  permutation_inplace<int*> ocb(b, b + 6, 3);

  oc.init (true);
  do
    {
      for (iterator i = oc.begin(); i != oc.end(); ++i)
	cout << *i << " ";
      cout << "| " ;
      for (iterator i = oc.unused_begin(); i != oc.unused_end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (oc.next ());

  cout << "=================" << endl;
  cin.get ();

  oc.init (false);
  do
    {
      for (iterator i = oc.begin(); i != oc.end(); ++i)
	cout << *i << " ";
      cout << "| " ;
      for (iterator i = oc.unused_begin(); i != oc.unused_end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (oc.prev ());

  cout << "=================" << endl;
  cin.get ();

  cout << endl << endl << "==========================" << endl;
  try
    {
      if (test_two_picker_equal (oc, oc2)
	  && test_two_picker_equal (oc, ocb))
	{
	  cout << "ok" << endl;
	}
    }
  catch (const char* err)
    {
      cout << "exception:" << err << endl;
    }

  int c[][5] = {{1, 2, 3, 4, 5},
		{1, 1, 3, 4, 5},
		{1, 2, 2, 3, 3},
		{1, 1, 1, 1, 1},
		{1, 3, 3, 3, 3},
		{1, 1, 2, 3, 3},
		{1, 1, 5, 5, 5}};

  for (int i = 0; i < sizeof(c) / sizeof(c[0]); ++i)
    {
      try
	{
	  gacap::permutation<int> c1;
	  c1.assign (c[i], c[i] + 5, 2);
	  gacap::permutation<int> c2(c[i], c[i] + 5, 0);
	  c2.set_length (2);
	  gacap::permutation<int> c3(c[i], c[i] + 5, 2);

	  test_two_picker_equal (c1, c2);
	  test_two_picker_equal (c2, c3);
	}
      catch (const char* err)
	{
	  cout << "exception: " << err << endl;
	  gacap::permutation<int> c3(c[i], c[i] + 5, 2);
	  c3.init (true);
	  do
	    {
	      sequence<iterator>(c3.begin(), c3.unused_end()).out ();
	    }
	  while (c3.next ());
	  cout << "  << next ||| prev >>  " << endl;
	  c3.init (false);
	  do
	    {
	      sequence<iterator>(c3.begin(), c3.unused_end()).out ();
	    }
	  while (c3.prev ());
	}
    }
  cin.get ();

  // test for function
  {
    typedef gacap::permutation_inplace<int*> t_inplace;
    typedef gacap::permutation<int> t;


    t_inplace ta(a, a + 5, 3);
    t tb(b, b + 5, 3);
    t_inplace(a, a + 3, a + 5, less<int>());
    t(b, b + 3, a + 5, less<int>());
    t_inplace();
    t();

    ta.assign (a, a + 5, 3);
    ta.assign (a, a + 3, a + 5);

    tb.assign (a, a + 5, 3);
    tb.assign (a, a + 3, a + 5);
  }
}
