#include <iostream>
#include <functional>
#include <vector>
using namespace std;

#include "../repeat_combination.hpp"
#include "../combination.hpp"
#include "compare.hpp"

int main ()
{
  int a[] = {1, 2, 3};

  typedef gacap::repeat_combination<int> repeat_combination;
  typedef repeat_combination::iterator iterator;
  repeat_combination rc(a, a + 3, 0);
  
  for (int n = 0; n < 3; ++n)
    {
      try
	{
	  rc.set_length (n);

	  int count_next = test_picker_next_count (rc);
	  cout << "count of next repeat_combination: " << count_next << endl;

	  int count_prev = test_picker_prev_count (rc);
	  cout << "count of prev repeat_combination: " << count_prev << endl;

	  cout << "test count of repeat_combination: "
	       << ((count_prev == count_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;


	  vector<int> tmp;
	  for (int i = 0; i < n; ++i)
	    tmp.insert (tmp.end(), a, a + 3);
	  gacap::combination<int> test_combi(tmp.begin(),
					     tmp.begin() + n,
					     tmp.end());

	  int combi_next = test_picker_next_count (test_combi);
	  cout << "count of next combination: " << combi_next << endl;

	  int combi_prev = test_picker_prev_count (test_combi);
	  cout << "count of prev combination: " << combi_prev << endl;

	  cout << "test count of combination: "
	       << ((combi_prev == combi_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;

	  cout << "repeat_combination vs combination: "
	       << ((combi_next == count_next) ? "ok" : "error")
	       << endl;
	  cout << "---------------------" << endl;

	  try
	    {
	      if (test_two_picker_equal (rc, test_combi))
		cout << "rc equal test_combi" << endl;
	    }
	  catch (const char* err)
	    {
	      cout << "rc don't equal test_combi: exception: " << endl;
	      cout << err << endl;
	    }

	  cout << endl << endl;
	}
      catch (const char* err)
	{
	  cout << "exception::::" << endl;
	  cout << err << endl;
	}
    }

  cout << "press ENTER to continue..." << endl;
  cin.get();

  rc.init (true);
  do
    {
      for (iterator i = rc.begin(); i != rc.end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (rc.next ());
  cout << "------------------" << endl;
  rc.prev ();
  do
    {
      for (iterator i = rc.begin(); i != rc.end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (rc.prev ());

  cout << "press ENTER to continue..." << endl;
  cin.get();

  rc.set_length (2);
  rc.prev ();
  do
    {
      for (iterator i = rc.begin(); i != rc.unused_end(); ++i)
	cout << *i << " ";
      cout << endl;
    }
  while (rc.prev ());

  cout << "press ENTER to exit..." << endl;
  cin.get();

  // test for function
  {
    typedef gacap::repeat_combination<int> t;

    t tb(a, a + 5, 3);
    t();

    tb.assign (a, a + 5, 3);
  }

  return 0;
}
