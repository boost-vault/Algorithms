#include "../permutation.hpp"
#include "../combination.hpp"
#include "../repeat_combination.hpp"
#include "../repeat_permutation.hpp"
using namespace gacap;

#include "compare.hpp"

#include <algorithm>
#include <iostream>
using namespace std;

template <class acap_t, class acap_ex_t>
void
test ()
{
  const int N = 5;
  int a[N];
  for (int i = 0; i < N; ++i)
    a[i] = i + 1;

  repeat_combination<int> data(a, a + N, N);
  for (int h = 0; h <= N; ++h)
    {
      data.set_length (h);
      
      cout << "------- length " << h << " length -------" << endl;

      for (int i = 0; i <= h; ++i)
	for (int j = i; j <= h; ++j)
	  {
	    cout << "[" << i  << "," << j << "]" << endl;
	    
	    do
	      {
		acap_t acap(data.begin(), data.end(), 0);
		acap_ex_t acap_ex(data.begin(), data.end(), 0, 0);
		
		try
		  {
		    int acap_count = 0;
		    for (int k = i; k <= j; ++k)
		      {
			acap.set_length (k);
			acap_count += test_picker_next_count (acap);
		      }
		    
		    acap_ex.set_length (i, j);
		    int next_count = test_picker_next_count (acap_ex);
		    int prev_count = test_picker_prev_count (acap_ex);
		    
		    if (next_count != prev_count)
		      {
			cout << "next != prev, while length: [" 
			     << i << ", " << j << "]"
			     << "result: next(" << next_count << ") vs "
			     << "prev(" << prev_count << ")"
			     << endl;
			
			test_picker_next_prev (acap_ex);
		      }
		    if (next_count != acap_count)
		      {
			cout << "next != acap, while length: [" 
			     << i << ", " << j << "]"
			     << "result: next(" << next_count << ") vs "
			     << "acap(" << acap_count << ")"
			     << endl;
		      }
		  }
		catch (const char* err)
		  {
		    cout << "[" << i << "," << j << "] exception: " 
			 << err << endl;
		  }
		catch (...)
		  {
		    cout << "[" << i << "," << j << "] unknown exception"
			 << endl;
		  }
	      }
	    while (data.next ());
	}
    }
}

template <class acap_ex_t>
void
out ()
{
  const int N = 4;
  int a[N];
  for (int i = 0; i < N; ++i)
    a[i] = i + 1;
  //a[0] = 2;
  //a[2] = 2;
  //a[3] = 2;

  acap_ex_t ex;

  ex.assign (a, a + N, 0, 0);

  for (int i = 0; i <= N; ++i)
    for (int j = i; j <= N; ++j)
      {
	cout << "range: [" << i << ", " << j << "]" << endl;
	ex.set_length (i, j);
	ex.init (true);

	do
	  {
	    for (typename acap_ex_t::iterator iter = ex.begin();
		 iter != ex.end(); ++iter)
	      {
		cout << *iter << " ";
	      }
	    cout << ", ";
	    for (typename acap_ex_t::iterator iter = ex.unused_begin();
		 iter != ex.unused_end(); ++iter)
	      {
		cout << *iter << " ";
	      }
	    cout << endl;
	  }
	while (ex.next());

	cout << "press ENTER to continue...";
	cin.get();
      }

  cout << "press ENTER goto prev...";
  cin.get();
  
  cout << endl << endl;


  for (int i = 0; i <= N; ++i)
    for (int j = i; j <= N; ++j)
      {
	cout << "range: [" << i << ", " << j << "]" << endl;
	ex.set_length (i, j);
	ex.init (false);

	do
	  {
	    for (typename acap_ex_t::iterator iter = ex.begin();
		 iter != ex.end(); ++iter)
	      {
		cout << *iter << " ";
	      }
	    cout << ",   ";
	    for (typename acap_ex_t::iterator iter = ex.unused_begin();
		 iter != ex.unused_end(); ++iter)
	      {
		cout << *iter << " ";
	      }
	    cout << endl;
	  }
	while (ex.prev());

	cout << "press ENTER to continue...";
	cin.get();
      }
}

int main()
{
  if (false)
    {
      cout << "permutation_ex..." << endl;
      
      out<permutation_ex<int> >();
      
      cout << endl << endl;
      cout << "press ENTER to continue...";
      cin.get();
    }

  if (false)
    {
      cout << "combination_ex...";

      out<combination_ex<int> >();
      
      cout << endl << endl;
      cout << "press ENTER to continue..."; 
      cin.get();
    }

  if (false)
    {
      cout << "repeat_permutation_ex...";

      out<repeat_permutation_ex<int> >();

      cout << endl << endl;
      cout << "press ENTER to continue...";
      cin.get();
    }

  if (false)
    {
      cout << "repeat_combination_ex...";

      out<repeat_combination_ex<int> >();

      cout << endl << endl;
      cout << "press ENTER to continue...";
      cin.get();
    }

  cout << "press ENTER to auto test...";
  cin.get();


  if (true)
    {
      cout << "combination_ex test:" << endl;
      test<combination<int>, combination_ex<int> >();
      cout << "-- end of combination_ex test --" << endl
	   << "press ENTER to continue..." << endl;
      cin.get();
    }

  if (true)
    {
      cout << "permutation_ex test:" << endl;
      test<permutation<int>, permutation_ex<int> >();
      cout << "-- end of permutation_ex test --" << endl
	   << "press ENTER to continue..." << endl;
      cin.get();
    }

  if (true)
    {
      cout << "repeat_permutation_ex test:" << endl;
      test<repeat_permutation<int>, repeat_permutation_ex<int> >();
      cout << "-- end of repeat_permutation_ex test --" << endl
	   << "press ENTER to continue..." << endl;
      cin.get();
    }
  
  if (true)
    {
      cout << "repeat_combination_ex test:" << endl;
      test<repeat_combination<int>, repeat_combination_ex<int> >();
      cout << "-- end of repeat_combination_ex test --" << endl
	   << "press ENTER to continue..." << endl;
      cin.get();
    }
  
  cout << "press ENTER to EXIT...";
  cin.get();
}
