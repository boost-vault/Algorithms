#include "../acap.hpp"
using namespace gacap;

#include "compare.hpp"

#include <iostream>
#include <cstring>
#include <functional>
using namespace std;

template <typename acap_t>
void
test_acap (int* first, int* last)
{
  int n = std::distance (first, last);
  int t = n / 2;

  acap_t cp1;
  cp1.assign (first, last, 0);
  cp1.set_length (t);
  acap_t cp2(first, last, 0);
  cp2.set_length (t);
  acap_t cp3(first, last, t);

  try
    {
      test_two_picker_equal (cp1, cp2);
      test_two_picker_equal (cp2, cp3);
    }
  catch (const char* err)
    {
      cout << "exception:: " << err << endl;
    }
}

int main()
{
  int a[][5] = {{1, 2, 3, 4, 5},
		{1, 1, 3, 4, 5},
		{1, 2, 2, 3, 3},
		{1, 1, 1, 1, 1},
		{1, 3, 3, 3, 3},
		{1, 1, 2, 3, 3},
		{1, 1, 5, 5, 5}};

  for (int i = 0; i < sizeof(a) / sizeof(a[0]); ++i)
    {
      {
	acap<false, false, int> t;
	test_acap<acap<false, false, int> >(a[i], a[i] + 5);
      }
      {
	acap<true, false, int> t;
	test_acap<acap<true, false, int> >(a[i], a[i] + 5);
      }
      {
	acap<false, true, int> t;
	test_acap<acap<false, true, int> >(a[i], a[i] + 5);
      }
      {
	acap<true, true, int> t;
	test_acap<acap<true, true, int> >(a[i], a[i] + 5);
      }
    }
}
