// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2007, BenBear
// benbearchen at gmail dot com
// 
// Under boost license

#ifndef __gacap_combi_utility_hpp_def
#define __gacap_combi_utility_hpp_def

namespace gacap
{
  ////////////////////////////////////////////////////////////////////
  // __twice_merge: merge [first1, last1) and [first2, last2), then
  //                fill the min element to [first1, last1), left to
  //                [first2, last2)
  ////////////////////////////////////////////////////////////////////
  template <typename Iter1, typename Iter2>
  void
  __twice_merge (Iter1 first1, Iter1 last1, 
		 Iter2 first2, Iter2 last2)
  {
    typedef typename std::iterator_traits<Iter1>::value_type value_type;
    typedef typename std::iterator_traits<Iter1>::difference_type diff_t;

    if ((first1 == last1) || (first2 == last2))
      return;

    diff_t len1 = std::distance(first1, last1);
    diff_t len2 = std::distance(first2, last2);
    diff_t lent = len1 + len2;
    value_type *tmp = new value_type[lent];

    std::merge (first1, last1, first2, last2, tmp);
    std::copy (tmp, tmp + len1, first1);
    std::copy (tmp + len1, tmp + lent, first2);

    delete[] tmp;
  }

  ////////////////////////////////////////////////////////////////////
  // __twice_merge: merge [first1, last1) and [first2, last2), then
  //                fill the min element to [first1, last1), left to
  //                [first2, last2)
  ////////////////////////////////////////////////////////////////////
  template <typename Iter1, typename Iter2, typename Comp>
  void
  __twice_merge (Iter1 first1, Iter1 last1, 
		 Iter2 first2, Iter2 last2, 
		 Comp comp)
  {
    typedef typename std::iterator_traits<Iter1>::value_type value_type;
    typedef typename std::iterator_traits<Iter1>::difference_type diff_t;

    if ((first1 == last1) || (first2 == last2))
      return;

    diff_t len1 = std::distance(first1, last1);
    diff_t len2 = std::distance(first2, last2);
    diff_t lent = len1 + len2;
    value_type *tmp = new value_type[lent];

    std::merge (first1, last1, first2, last2, tmp, comp);
    std::copy (tmp, tmp + len1, first1);
    std::copy (tmp + len1, tmp + lent, first2);

    delete[] tmp;
  }

  ////////////////////////////////////////////////////////////////////
  // __twice_merge: merge [first1, last1) and [first2, last2), then
  //                fill the min element to [first1, last1), left to
  //                [first2, last2), using buffer
  ////////////////////////////////////////////////////////////////////
  template <typename Iter1, typename Iter2, 
	    typename Iter3, typename Comp>
  void
  __twice_merge (Iter1 first1, Iter1 last1, 
		 Iter2 first2, Iter2 last2,
		 Iter3 buffer, Comp comp)
  {
    typedef typename std::iterator_traits<Iter1>::value_type value_type;
    typedef typename std::iterator_traits<Iter1>::difference_type diff_t;

    if ((first1 == last1) || (first2 == last2))
      return;

    diff_t len1 = std::distance(first1, last1);
    diff_t len2 = std::distance(first2, last2);
    diff_t lent = len1 + len2;

    std::merge (first1, last1, first2, last2, buffer, comp);
    std::copy (buffer, buffer + len1, first1);
    std::copy (buffer + len1, buffer + lent, first2);
  }

  ///////////////////////////////////////////////////////////////////
  // __sort_combination: merge sort the [first, last)
  ///////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  void
  __sort_combination (BiIter first, BiIter last, Comp comp)
  {
    typedef typename std::iterator_traits<BiIter>::difference_type diff_t;
    diff_t len = std::distance(first, last);
    if (len <= 1)
      return;

    if (len == 2)
      {
	if (comp(*--last, *first))
	  std::iter_swap (first, last);
      }
    else
      {
	BiIter middle = first;
	std::advance(middle, len / 2);
	__sort_combination (first, middle, comp);
	__sort_combination (middle, last, comp);
	__twice_merge (first, middle, middle, last, comp);
      }
  }

  ///////////////////////////////////////////////////////////////////
  // __sort_combination: merge sort the [first, last)
  ///////////////////////////////////////////////////////////////////
  template <typename BiIter, typename BufferIter, typename Comp>
  void
  __sort_combination (BiIter first, BiIter last, BufferIter buffer, Comp comp)
  {
    typedef typename std::iterator_traits<BiIter>::difference_type diff_t;
    diff_t len = std::distance(first, last);
    if (len <= 1)
      return;

    if (len == 2)
      {
	if (comp(*--last, *first))
	  std::iter_swap (first, last);
      }
    else
      {
	BiIter middle = first;
	std::advance(middle, len / 2);
	__sort_combination (first, middle, buffer, comp);
	__sort_combination (middle, last, buffer, comp);
	__twice_merge (first, middle, middle, last, 
		       buffer, comp);
      }
  }

  ///////////////////////////////////////////////////////////////////
  // __sort_combination: merge sort the [first, last)
  ///////////////////////////////////////////////////////////////////
  template <typename BiIter>
  void
  __sort_combination (BiIter first, BiIter last)
  {
    typedef typename std::iterator_traits<BiIter>::difference_type diff_t;
    diff_t len = std::distance(first, last);
    if (len <= 1)
      return;

    if (len == 2)
      {
	if (*--last < *first)
	  std::iter_swap (first, last);
      }
    else
      {
	BiIter middle = first;
	std::advance(middle, len / 2);
	__sort_combination (first, middle);
	__sort_combination (middle, last);
	__twice_merge (first, middle, middle, last);
      }
  }

  ///////////////////////////////////////////////////////////////////
  // __combination_merge_right: merge the two right parts in
  //                            combination, 
  ///////////////////////////////////////////////////////////////////
  template <typename BiIter1, typename BiIter2>
  void
  __combination_merge_right (BiIter1 first1, BiIter1 last1,
			     BiIter2 first2, BiIter2 last2)
  {
    if ((first1 == last1) || (first2 == last2))
      return;

    BiIter1 m1 = last1;
    BiIter2 m2 = first2;
    while ((m1 != first1) && (m2 != last2))
      std::iter_swap (--m1, m2++);

    std::reverse (first1, m1);
    std::reverse (first1, last1);

    std::reverse (m2, last2);
    std::reverse (first2, last2);
  }
}

#endif

