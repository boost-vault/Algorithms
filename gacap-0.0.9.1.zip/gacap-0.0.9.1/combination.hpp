// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2004 - 2007, BenBear
// benbearchen at gmail dot com
//
// Under boost license

#ifndef __gacap_combination_hpp_def
#define __gacap_combination_hpp_def

#include <algorithm>
#include <iterator>
#include <vector>
#include <functional>
#include <cassert>

#include "iterator_proxy.hpp"
#include "combi_utility.hpp"

namespace gacap
{
  //////////////////////////////////////////////////////////////////////
  // init_combination: init the (first, midle, last) to the min or the
  //                   max combination
  //////////////////////////////////////////////////////////////////////
  template <typename BiIter>
  void
  init_combination (BiIter first, BiIter middle, BiIter last, 
		    bool min = true)
  {
    __sort_combination (first, middle);
    __sort_combination (middle, last);
    if (min)
      __twice_merge (first, middle, middle, last);
    else
      __twice_merge (middle, last, first, middle);
  }

  //////////////////////////////////////////////////////////////////////
  // init_combination: init the (first, midle, last) to the min or the
  //                   max combination
  //////////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  void
  init_combination (BiIter first, BiIter middle, BiIter last, 
		    bool min, Comp comp)
  {
    __sort_combination (first, middle, comp);
    __sort_combination (middle, last, comp);
    if (min)
      __twice_merge (first, middle, middle, last, comp);
    else
      __twice_merge (middle, last, first, middle, comp);
  }

  //////////////////////////////////////////////////////////////////////
  // adjust_combination: make the (first, middle, last) to a right
  //                     combination. [first, middle) are the elements
  //                     selected in, [middle, last) are selected out
  //////////////////////////////////////////////////////////////////////
  template <typename BiIter>
  void
  adjust_combination (BiIter first, BiIter middle, BiIter last)
  {
    __sort_combination (first, middle);
    __sort_combination (middle, last);
  }

  //////////////////////////////////////////////////////////////////////
  // adjust_combination: make the (first, middle, last) to a right
  //                     combination. [first, middle) are the elements
  //                     selected in, [middle, last) are selected out
  //////////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  void
  adjust_combination (BiIter first, BiIter middle, BiIter last,
		      Comp comp)
  {
    __sort_combination (first, middle, comp);
    __sort_combination (middle, last, comp);
  }

  /////////////////////////////////////////////////////////////////////
  // __do_next_combination: get next combination.
  //
  // [first1, last1): the elements selected in \\
  // [first2, last2): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter>
  bool
  __do_next_combination (BiIter first1, BiIter last1, 
			 BiIter first2, BiIter last2)
  {
    if ((first1 == last1) || (first2 == last2))
      return false;

    BiIter qmax = last2;
    --qmax;
    BiIter pout1 = std::lower_bound(first1, last1, *qmax);
    bool fin = pout1 == first1;
    BiIter left1, left2;
    if (!fin)
      {
	BiIter pout = pout1;
	--pout;
	BiIter qin = std::upper_bound(first2, last2, *pout);
	std::iter_swap (pout, qin);
	left1 = pout;
	++left1;
	left2 = qin;
	++left2;
      }
    else
      {
	left1 = first1;
	left2 = first2;
      }
    __combination_merge_right (left1, last1, left2, last2);
    return !fin;
  }

  /////////////////////////////////////////////////////////////////////
  // __do_next_combination: get next combination.
  //
  // [first1, last1): the elements selected in \\
  // [first2, last2): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  bool
  __do_next_combination (BiIter first1, BiIter last1, 
			 BiIter first2, BiIter last2,
			 Comp comp)
  {
    if ((first1 == last1) || (first2 == last2))
      return false;

    BiIter qmax = last2;
    --qmax;
    BiIter pout1 = std::lower_bound(first1, last1, *qmax, comp);
    bool fin = pout1 == first1;
    BiIter left1, left2;
    if (!fin)
      {
	BiIter pout = pout1;
	--pout;
	BiIter qin = std::upper_bound(first2, last2, *pout, comp);
	std::iter_swap (pout, qin);
	left1 = pout;
	++left1;
	left2 = qin;
	++left2;
      }
    else
      {
	left1 = first1;
	left2 = first2;
      }
    __combination_merge_right (left1, last1, left2, last2);
    return !fin;
  }

  /////////////////////////////////////////////////////////////////////
  // next_combination: get next combination.
  //
  // [first, middle): the elements selected in \\
  // [middle, last): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter>
  inline bool
  next_combination (BiIter first, BiIter middle, BiIter last)
  {
    return __do_next_combination (first, middle, middle, last);
  }

  /////////////////////////////////////////////////////////////////////
  // next_combination: get next combination.
  //
  // [first, middle): the elements selected in \\
  // [middle, last): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  inline bool
  next_combination (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    return __do_next_combination (first, middle, 
				  middle, last, 
				  comp);
  }

  /////////////////////////////////////////////////////////////////////
  // prev_combination: get prev combination.
  //
  // [first, middle): the elements selected in \\
  // [middle, last): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter>
  inline bool 
  prev_combination (BiIter first, BiIter middle, BiIter last)
  {
    return __do_next_combination (middle, last, first, middle);
  }

  /////////////////////////////////////////////////////////////////////
  // prev_combination: get prev combination.
  //
  // [first, middle): the elements selected in \\
  // [middle, last): the elements selected out
  /////////////////////////////////////////////////////////////////////
  template <typename BiIter, typename Comp>
  inline bool 
  prev_combination (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    return __do_next_combination (middle, last, 
				  first, middle, 
				  comp);
  }

  template <typename BiIter, 
	    typename Comp = std::less<typename std::iterator_traits<BiIter>::value_type> >
  class combination_inplace
  {
  public:
    typedef typename std::iterator_traits<BiIter>::value_type value_type;
    typedef typename std::iterator_traits<BiIter>::difference_type difference_type;

    typedef proxy_const_iterator<BiIter> iterator;

  private:
    BiIter _first;
    BiIter _middle;
    BiIter _last;

    Comp _comp;

  public:
    explicit
    combination_inplace (Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (BiIter(), BiIter(), 0);
    }

    combination_inplace (BiIter first, BiIter middle, BiIter last,
			 Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (first, middle, last);
    }

    combination_inplace (BiIter first, BiIter last, 
			 difference_type m, 
			 Comp comp = Comp())
      : _first(), _middle(), _last(), _comp(comp)
    {
      assign (first, last, m);
    }
  public:
    void
    assign (BiIter first, BiIter middle, BiIter last)
    {
      assign (first, last, std::distance (first, middle));
    }

    void
    assign (BiIter first, BiIter last, difference_type m)
    {
      _first = first;
      _last = last;
      
      set_length (m);
    }

    void
    set_length (difference_type m)
    {
      difference_type len = std::distance (_first, _last);
      if (m > len)
	m = len;

      _middle = _first;
      std::advance (_middle, m);
      
      adjust ();
    }

    void
    init (bool min)
    {
      init_combination (_first, _middle, _last, min, _comp);
    }

  private:
    void
    adjust ()
    {
      adjust_combination (_first, _middle, _last, _comp);
    }

  public:
    bool
    next ()
    {
      return next_combination (_first, _middle, _last, _comp);
    }

    bool
    prev ()
    {
      return prev_combination (_first, _middle, _last, _comp);
    }

    iterator
    begin() const
    {
      return iterator(_first);
    }
    iterator
    end() const
    {
      return iterator(_middle);
    }
    iterator
    unused_begin() const
    {
      return iterator(_middle);
    }
    iterator
    unused_end() const
    {
      return iterator(_last);
    }
  };

  template <typename T, 
	    typename Comp = std::less<T> >
  class combination
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

  private:
    typedef iterator_bridge<T> bridge_type;
    typedef bridge_type* inner_iterator;
    typedef proxy_compare<T, Comp> compare_type;

  public:
    typedef proxy_iterator<T> iterator;

  private:
    combination_inplace<inner_iterator, compare_type> _combi;
    std::vector<bridge_type> _iterators;

  public:
    explicit
    combination (Comp comp = Comp())
      : _combi(compare_type(comp))
    {
    }

    template <typename Iter>
    combination (Iter first, Iter middle, Iter last, 
		 Comp comp = Comp())
      : _combi(compare_type(comp))
    {
      assign (first, middle, last);
    }

    template <typename Iter>
    combination (Iter first, Iter last, difference_type m, 
		 Comp comp = Comp())
      : _combi(compare_type(comp))
    {
      assign (first, last, m);
    }
  public:
    template <typename Iter>
    void
    assign (Iter first, Iter middle, Iter last)
    {
      assign (first, last, std::distance (first, middle));
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, difference_type m)
    {
      _iterators.clear ();
      _iterators.reserve (std::distance (first, last));
      for (Iter i = first; i != last; ++i)
	_iterators.push_back (bridge_type(i));

      inner_iterator _first = &_iterators.front();
      inner_iterator _last = _first + _iterators.size();
      
      _combi.assign (_first, _last, m);
    }

    void
    set_length (difference_type m)
    {
      _combi.set_length (m);
    }

    void
    init (bool min)
    {
      _combi.init (min);
    }

  private:
    void
    adjust ()
    {
      _combi.adjust ();
    }

  public:
    bool
    next ()
    {
      return _combi.next();
    }

    bool
    prev ()
    {
      return _combi.prev ();
    }

    iterator
    begin() const
    {
      return iterator(_combi.begin());
    }
    iterator
    end() const
    {
      return iterator(_combi.end());
    }
    iterator
    unused_begin() const
    {
      return iterator(_combi.unused_begin());
    }
    iterator
    unused_end() const
    {
      return iterator(_combi.unused_end());
    }
  };

  template <typename T,
	    typename Comp = std::less<T> >
  class combination_ex
  {
  public:
    typedef T value_type;
    typedef ptrdiff_t difference_type;

  private:
    typedef iterator_bridge<T> bridge_type;
    typedef typename std::vector<bridge_type>::iterator iter;
    typedef proxy_compare<T, Comp> compare_type;

  public:
    class iterator:
      public std::iterator<std::bidirectional_iterator_tag, T>
    {
    public:
      typedef T value_type;
      typedef const value_type& const_reference;
      typedef const value_type* const_pointer;
      typedef typename std::vector<bridge_type>::const_iterator item_iterator;

    private:
      friend class combination_ex;

      item_iterator _item;

      iterator (item_iterator item)
	: _item(item)
      {
      }

    public:
      iterator ()
      {
      }

      iterator&
      operator ++ ()
      {
	++_item;

	return *this;
      }

      iterator
      operator ++ (int)
      {
	iterator iter = *this;
	++*this;
	return iter;
      }

      iterator&
      operator -- ()
      {
	--_item;

	return *this;
      }

      iterator
      operator -- (int)
      {
	iterator iter = *this;
	--*this;
	return iter;
      }

      bool
      operator == (const iterator& rhs) const
      {
	return _item == rhs._item;
      }

      bool
      operator != (const iterator& rhs) const
      {
	return !(*this == rhs);
      }

      const_reference
      operator * () const
      {
	return (*_item).ref();
      }

      const_pointer
      operator -> () const
      {
	return &**this;
      }
    };

  private:
    std::vector<bridge_type> _values;

    compare_type _comp;

    difference_type _len;

    difference_type _min_len;
    difference_type _max_len;

  public:
    explicit
    combination_ex (Comp comp = Comp())
      : _comp(comp)
    {
      assign ((T*)0, (T*)0, 0, 0);
    }

    template <typename Iter>
    combination_ex (Iter first, Iter last,
		    difference_type min_len, 
		    difference_type max_len,
		    Comp comp = Comp())
      : _comp(comp)
    {
      assign (first, last, min_len, max_len);
    }

    template <typename Iter>
    void
    assign (Iter first, Iter last, 
	    difference_type min_len, 
	    difference_type max_len)
    {
      _values.clear ();
      _values.reserve (std::distance (first, last));
      for (Iter i = first; i != last; ++i)
	_values.push_back (bridge_type(i));
      
      set_length (min_len, max_len);
    }

    void
    set_length (difference_type min_len, 
		difference_type max_len)
    {
      assert ((min_len >= 0) && (max_len >= min_len));

      if (max_len > _values.size())
	max_len = _values.size();

      _min_len = min_len;
      _max_len = max_len;

      init (true);
    }

  private:
    // helper function
    iter
    find_greatest_elements (iter first, iter last)
    {
      if (first == last)
	return last;
      iter e = last;
      while (--e != first)
	{
	  iter f = e;
	  if (_comp(*--f, *e))
	    break;
	}
      return e;
    }
    
  public:
    void
    init (bool min)
    {
      if (min)
	{
	  _len = _min_len;
	  init_combination (_values.begin(), _values.begin() + _min_len, 
			    _values.end(), min, _comp);
	}
      else
	{
	  __sort_combination (_values.begin(), _values.end(), _comp);
	  iter first = _values.begin();
	  iter last = _values.end();
	  iter g = find_greatest_elements (first, last);

	  difference_type len = std::distance (g, last);
	  if (len > _max_len)
	    len = _max_len;
	  else if (len < _min_len)
	    len = _min_len;
	  iter middle = first + len;
	  std::reverse (first, last);
	  std::reverse (first, middle);
	  std::reverse (middle, last);

	  _len = len;
	}
    }

    bool
    next ()
    {
      if (_values.empty() || (_max_len == 0))
	return false;

      if (_len == 0)
	{
	  ++_len;
	  return true;
	}
      
      iter first = _values.begin();
      iter middle = first + _len;
      iter last = _values.end();

      // end of front part
      iter fe = middle - 1;
      iter be = last - 1;

      if ((_len != _max_len)
	  && !_comp(*be, *fe))
	{
	  iter b = std::lower_bound (middle, last, *fe, _comp);
	  std::reverse (middle, b);
	  std::reverse (middle, ++b);

	  ++_len;

	  return true;
	}

      if ((middle != last) && _comp(*fe, *be))
	{
	  iter b = std::upper_bound (middle, last, *fe, _comp);
	  std::iter_swap (fe, b);
	  
	  return true;
	}
      
      iter s = find_greatest_elements (first, middle);

      if ((s == first)
	  || ((_len == _min_len)
	      && ((middle == last) || !_comp(*first, *be))))
	{
	  // can't become big more
	  init (true);
	  return false;
	}

      --s;
      
      if ((_len != _min_len)
	  && ((middle == last || !_comp(*s, *be))))
	{
	  std::iter_swap (s, fe);
	  
	  difference_type len = std::distance (first, ++s);
	  if (len < _min_len)
	    len = _min_len;
	  iter m = first + len;
	  
	  std::reverse (middle, last);
	  std::reverse (m, last);
	  _len = len;
	  
	  return true;
	}

      iter f = std::lower_bound (first, middle, *be, _comp);
      --f;
      iter b = std::upper_bound (middle, last, *f, _comp);
      std::iter_swap (f, b);
      
      __combination_merge_right (++f, middle, ++b, last);
      
      difference_type len = std::distance (first, f);
      if (len < _min_len)
	len = _min_len;
      
      iter r = first + len;
      std::reverse (r, middle);
      std::reverse (middle, b);
      std::reverse (r, b);
      
      _len = len;
      
      return true;
    }

    bool
    prev ()
    {
      if (_values.empty() || (_max_len == 0))
	return false;

      if (_len == 0)
	{
	  init (false);
	  return false;
	}

      iter first = _values.begin();
      iter middle = first + _len;
      iter last = _values.end();

      if (middle == last)
	{
	  if (_len != _min_len)
	    {
	      --_len;
	      return true;
	    }
	  else
	    {
	      init (false);
	      return false;
	    }
	}

      iter fe = middle - 1;
      iter be = last - 1;

      iter s = std::lower_bound (middle, last, *fe, _comp);
      
      if (_len != _min_len)
	{
	  if ((s == middle) 
	      || ((fe != first) && _comp(*(s - 1), *(fe - 1))))
	    {
	      --_len;
	      std::reverse (middle, s);
	      std::reverse (fe, s);
	      return true;
	    }
	}

      if (s != middle)
	{
	  --s;
	  iter b = std::upper_bound (first, middle, *s, _comp);
	  std::iter_swap (s, b);
	  
	  std::reverse (++b, middle);
	  std::reverse (middle, ++s);
	  std::reverse (b, s);

	  iter g = find_greatest_elements (b, last);
	  difference_type g_len = std::distance (g, last);
	  difference_type len = std::distance (first, b);
	  if (g_len + len > _max_len)
	    g_len = _max_len - len;
	  else if (g_len + len < _min_len)
	    g_len = _min_len - len;
	  iter m = b + g_len;
	  std::reverse (b, last);
	  std::reverse (b, m);
	  std::reverse (m, last);

	  _len = len + g_len;
	  
	  return true;
	}
      
      init (false);
      return false;
    }

    iterator
    begin() const
    {
      return iterator(_values.begin());
    }
    iterator
    end() const
    {
      return iterator(_values.begin() + _len);
    }
    iterator
    unused_begin() const
    {
      return end();
    }
    iterator
    unused_end() const
    {
      return iterator(_values.end());
    }
  };
}

#endif
