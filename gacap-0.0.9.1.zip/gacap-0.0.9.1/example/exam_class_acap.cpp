#include "../acap.hpp"
using namespace gacap;

#include <iostream>
#include <string>
using namespace std;

template <typename Iter>
void out (Iter begin, Iter end, 
	  Iter unused_begin, Iter unused_end)
{
  for (Iter i = begin; i != end; ++i)
    cout << "\t" << *i;

  if (unused_begin != unused_end)
    {
      cout << "\t\t[" << *unused_begin;
      for (Iter i = unused_begin; ++i != unused_end;)
	cout << "\t" << *i;
      cout << "\t]";
    }
  cout << endl;
}

template <typename acap, typename Iter>
void
show (Iter first, Iter last, int n)
{
  cout << " ---- " << endl;

  cout << " show value after construct/assign/set_length: " << endl;
  {
    acap cp1(first, last, n);
    out (cp1.begin(), cp1.end(),
	 cp1.unused_begin(), cp1.unused_end());
  }
  {
    acap cp3;
    cp3.assign (first, last, n);
    out (cp3.begin(), cp3.end(),
	 cp3.unused_begin(), cp3.unused_end());
  }

  cout << " ---- " << endl;
  cout << " press ENTER to continue...";
  cin.get ();

  acap cp5(first, last, n);
  cp5.init (true);
  cout << " from the minimum to the maximum: " << endl;
  do
    {
      out (cp5.begin(), cp5.end(),
	   cp5.unused_begin(), cp5.unused_end());
    }
  while (cp5.next ());

  cout << " ---- " << endl;
  cout << " press ENTER to continue...";
  cin.get ();

  cp5.init (false);
  cout << " from the maximum to the minimum: " << endl;
  do
    {
      out (cp5.begin(), cp5.end(),
	   cp5.unused_begin(), cp5.unused_end());
    }
  while (cp5.prev ());

  cout << " ---- " << endl;
}

template <typename acap_ex, typename Iter>
void
show_ex (Iter first, Iter last, int min, int max)
{
  cout << " ---- " << endl;

  cout << " show value after construct/assign/set_length: " << endl;
  {
    acap_ex cp1(first, last, min, max);
    out (cp1.begin(), cp1.end(),
	 cp1.unused_begin(), cp1.unused_end());
  }
  {
    acap_ex cp3;
    cp3.assign (first, last, min, max);
    out (cp3.begin(), cp3.end(),
	 cp3.unused_begin(), cp3.unused_end());
  }

  cout << " ---- " << endl;
  cout << " press ENTER to continue...";
  cin.get ();

  acap_ex cp5(first, last, min, max);
  cp5.init (true);
  cout << " from the minimum to the maximum: " << endl;
  do
    {
      out (cp5.begin(), cp5.end(),
	   cp5.unused_begin(), cp5.unused_end());
    }
  while (cp5.next ());

  cout << " ---- " << endl;
  cout << " press ENTER to continue...";
  cin.get ();

  cp5.init (false);
  cout << " from the maximum to the minimum: " << endl;
  do
    {
      out (cp5.begin(), cp5.end(),
	   cp5.unused_begin(), cp5.unused_end());
    }
  while (cp5.prev ());

  cout << " ---- " << endl;
}

int main ()
{
  string s[5] = {"Jack", "Bob", "Susan", "Alex", "David"};

  cout << " acap act combination: " << endl;
  show<acap<false, false, string> > (s, s + 5, 3);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act permutation with greater: " << endl;
  show<acap<true, false, string, greater<string> > > (s, s + 5, 2);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act repeat_combination: " << endl;
  show<acap<false, true, string> > (s, s + 5, 2);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act repeat_permutation: " << endl;
  show<acap<true, true, string> > (s, s + 5, 2);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act combination_ex: " << endl;
  show_ex<acap_ex<false, false, string> > (s, s + 5, 0, 2);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act permutation_ex: " << endl;
  show_ex<acap_ex<true, false, string> > (s, s + 5, 1, 3);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act repeat_combination_ex: " << endl;
  show_ex<acap_ex<false, true, string> > (s, s + 5, 2, 3);
  cout << " press ENTER to continue...";
  cin.get ();

  cout << endl << " acap act repeat_permutation_ex: " << endl;
  show_ex<acap_ex<true, true, string> > (s, s + 5, 2, 2);
  cout << " press ENTER to EXIT...";
  cin.get ();
}
