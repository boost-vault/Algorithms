#include "../acap.hpp"
using namespace gacap;

#include <iostream>
#include <string>
using namespace std;

template <typename Iter>
void 
out (Iter begin, Iter end)
{
  cout << "`";
  for (Iter i = begin; i != end; ++i)
    cout << " " << *i;
  cout << " '" << endl;
}

int main()
{
  int a[4] = {1, 2, 3, 4};

  combination_ex<int> ex(a, a + 4, 0, 4);
  do
    {
      out (ex.begin(), ex.end());
    }
  while (ex.next ());
      
  cin.get ();
}
