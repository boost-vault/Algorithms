#include "../permutation.hpp"
#include "../combination.hpp"
#include "../repeat_permutation.hpp"
#include "../repeat_combination.hpp"
using namespace gacap;

#include <iostream>
#include <algorithm>
using namespace std;

template <typename Iter>
void
out (Iter first, Iter last)
{
  for (Iter i = first; i != last; ++i)
    cout << *i << " ";
  cout << endl;
}

int main()
{
  const int N = 3;
  int a[N] = {0};

  fill (a, a + N, 1);
  cout << "next_repeat_combination:" << endl;
  do
    {
      out (a, a + N);
    }
  while (next_repeat_combination (a, a + N, 1, 4));
  cout << "press ENTER to continue...";
  cin.get ();

  prev_repeat_combination (a, a + N, 1, 4);

  cout << "prev_repeat_combination:" << endl;
  do
    {
      out (a, a + N);
    }
  while (prev_repeat_combination (a, a + N, 1, 4));
  cout << "press ENTER to continue...";
  cin.get ();

  
  fill (a, a + N, 0);
  a[0] = 3;
  cout << "next_repeat_combination(by count):" << endl;
  do
    {
      cout << "tranlated:[";
      for (int i = 0; i < N; ++i)
	for (int j = 0; j < a[i]; ++j)
	  cout << i + 1 << " ";
      cout << "\b]  original:";
      out (a, a + N);
    }
  while (next_repeat_combination (a, a + N));
  cout << "press ENTER to continue...";
  cin.get ();

  prev_repeat_combination (a, a + N);

  cout << "prev_repeat_combination(by count):" << endl;
  do
    {
      cout << "[";
      for (int i = 0; i < N; ++i)
	for (int j = 0; j < a[i]; ++j)
	  cout << i + 1 << " ";
      cout << "\b]  ";
      out (a, a + N);
    }
  while (prev_repeat_combination (a, a + N));
  cout << "press ENTER to continue...";
  cin.get ();


  fill (a, a + N, 1);
  cout << "next_repeat_permutation:" << endl;
  do
    {
      out (a, a + N);
    }
  while (next_repeat_permutation (a, a + N, 1, 4));
  cout << "press ENTER to continue...";
  cin.get ();

  prev_repeat_permutation (a, a + N, 1, 4);

  cout << "prev_repeat_permutation:" << endl;
  do
    {
      out (a, a + N);
    }
  while (prev_repeat_permutation (a, a + N, 1, 4));
  cout << "press ENTER to continue...";
  cin.get ();


  for (int i = 0; i < N; ++i)
    a[i] = i + 1;
  cout << "next_combination:" << endl;
  do
    {
      out (a, a + N - N / 2);
    }
  while (next_combination (a, a + N - N / 2, a + N));
  cout << "press ENTER to continue...";
  cin.get ();

  prev_combination (a, a + N - N / 2, a + N);
  
  cout << "prev_combination:" << endl;
  do
    {
      out (a, a + N - N / 2);
    }
  while (prev_combination (a, a + N - N / 2, a + N));
  cout << "press ENTER to continue...";
  cin.get ();

  next_combination (a, a + N - N / 2, a + N);

  
  cout << "next_partial_permutation:" << endl;
  do
    {
      out (a, a + N - N / 2);
    }
  while (next_partial_permutation (a, a + N - N / 2, a + N));
  cout << "press ENTER to continue...";
  cin.get ();

  prev_partial_permutation (a, a + N - N / 2, a + N);
  
  cout << "prev_partial_permutation:" << endl;
  do
    {
      out (a, a + N - N / 2);
    }
  while (prev_partial_permutation (a, a + N - N / 2, a + N));
  cout << "press ENTER to continue...";
  cin.get ();

  
  cout << "press ENTER to EXIT...";
  cin.get ();
}
