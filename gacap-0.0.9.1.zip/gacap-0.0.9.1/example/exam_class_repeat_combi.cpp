#include "../repeat_combination.hpp"
using namespace gacap;

#include <iostream>
using namespace std;

template <typename Iter>
void out (Iter begin, Iter end, 
	  Iter unused_begin, Iter unused_end)
{
  for (Iter i = begin; i != end; ++i)
    cout << "\t" << *i;

  cout << "\t   |";

  for (Iter i = unused_begin; i != unused_end; ++i)
    cout << "\t" << *i;

  cout << endl;
}

int main ()
{
  char a[5] = {'a', 'b', 'c', 'd', 'e'};

  repeat_combination<char> rc;

  int k = 2, n = 4;

  cout << endl
       << "select 2 from 4, generate from smallest to largest:"
       << endl;
  // initialize to the smallest sequence
  rc.assign (a, a + n, 0);
  rc.set_length (k);
  rc.init (true);
  
  // generate loop
  do
    {
      // use the sequence
      out (rc.begin(), rc.end(),
	   rc.unused_begin(), rc.unused_end());
    }
  // generate to next sequence, and judge whether end
  while (rc.next());
  cout << "press ENTER to continue...";
  cin.get();


  cout << endl
       << "select 2 from 4, generate from largest to smallest:"
       << endl;
  // previous loop
  rc.assign (a, a + n, k);
  rc.init (false);
  do
    {
      out (rc.begin(), rc.end(),
	   rc.unused_begin(), rc.unused_end());
    }
  while (rc.prev());
  cout << "press ENTER to finish...";
  cin.get();
}
