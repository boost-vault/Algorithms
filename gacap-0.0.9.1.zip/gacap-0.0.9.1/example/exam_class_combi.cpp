#include "../combination.hpp"
using namespace gacap;

#include <iostream>
using namespace std;

template <typename Iter>
void out (Iter begin, Iter end, 
	  Iter unused_begin, Iter unused_end)
{
  for (Iter i = begin; i != end; ++i)
    cout << "\t" << *i;

  if (unused_begin != unused_end)
    {
      cout << "\t[" << *unused_begin;
      for (Iter i = unused_begin; ++i != unused_end;)
	cout << "\t" << *i;
      cout << "]";
    }
  cout << endl;
}

int main ()
{
  char a[5] = {'a', 'b', 'c', 'd', 'e'};

  combination_inplace<char*> combi;

  int k = 2, n = 5;

  cout << endl
       << "select 2 from 5, generate from smallest to largest:"
       << endl;
  // initialize to the smallest sequence
  combi.assign (a, a + k, a + n);
  combi.init (true);
  
  // generate loop
  do
    {
      // use the sequence
      out (combi.begin(), combi.end(), 
	   combi.unused_begin(), combi.unused_end());
    }
  // generate to next sequence, and judge whether end
  while (combi.next());
  cout << "press ENTER to continue...";
  cin.get();


  k = n - k;

  cout << endl
       << "select 3 from 5, generate from largest to smallest:"
       << endl;
  // previous loop
  combi.assign (a, a + k, a + n);
  combi.init (false);
  do
    {
      out (combi.begin(), combi.end(),
	   combi.unused_begin(), combi.unused_end());
    }
  while (combi.prev());
  cout << "press ENTER to finish...";
  cin.get();
}
