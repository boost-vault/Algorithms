#include "../permutation.hpp"
using namespace gacap;

#include <iostream>
using namespace std;

template <typename Iter>
void out (Iter begin, Iter end)
{
  for (Iter i = begin; i != end; ++i)
    cout << "\t" << *i;

  cout << endl;
}

int main ()
{
  char a[5] = {'a', 'b', 'c', 'd', 'e'};

  permutation<char> permu;

  int n = 3;

  cout << endl
       << "3 elements, generate from smallest to largest:"
       << endl;
  // initialize to the smallest sequence
  permu.assign (a, a + n, 0);
  permu.set_length (n);
  permu.init (true);
  
  // generate loop
  do
    {
      // use the sequence
      out (permu.begin(), permu.end());
    }
  // generate to next sequence, and judge whether end
  while (permu.next());
  cout << "press ENTER to continue...";
  cin.get();


  cout << endl
       << "3 elements, generate from largest to smallest:"
       << endl;
  // previous loop
  permu.assign (a, a + n, n);
  permu.init (false);
  do
    {
      out (permu.begin(), permu.end());
    }
  while (permu.prev());
  cout << "press ENTER to finish...";
  cin.get();
}
