#include "../repeat_permutation.hpp"
using namespace gacap;

#include <iostream>
using namespace std;

template <typename Iter>
void out (Iter begin, Iter end, 
	  Iter unused_begin, Iter unused_end)
{
  for (Iter i = begin; i != end; ++i)
    cout << "\t" << *i;

  cout << "\t   |";

  for (Iter i = unused_begin; i != unused_end; ++i)
    cout << "\t" << *i;

  cout << endl;
}

int main ()
{
  char a[5] = {'a', 'b', 'c', 'd', 'e'};

  repeat_permutation<char> select;

  int k = 2, n = 4;

  cout << endl
       << "select 2 from 4, generate from smallest to largest:"
       << endl;
  // initialize to the smallest sequence
  select.assign (a, a + n, k);
  select.init (true);
  
  // generate loop
  do
    {
      // use the sequence
      out (select.begin(), select.end(),
	   select.unused_begin(), select.unused_end());
    }
  // generate to next sequence, and judge whether end
  while (select.next());
  cout << "press ENTER to continue...";
  cin.get();


  cout << endl
       << "select 2 from 4, generate from largest to smallest:"
       << endl;
  // previous loop
  select.assign (a, a + n, k);
  select.init (false);
  do
    {
      out (select.begin(), select.end(),
	   select.unused_begin(), select.unused_end());
    }
  while (select.prev());
  cout << "press ENTER to finish...";
  cin.get();
}
