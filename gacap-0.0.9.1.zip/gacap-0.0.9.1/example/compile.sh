#!/bin/bash

../test/compile.sh
