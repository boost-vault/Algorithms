// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2007, BenBear
// benbearchen at gmail dot com
// 
// Under boost license

#ifndef __gacap_iterator_proxy_hpp_def
#define __gacap_iterator_proxy_hpp_def

#include <iterator>
#include <functional>

namespace gacap
{
  template <typename BiIter>
  class proxy_const_iterator: 
    public std::iterator<std::bidirectional_iterator_tag,
			 typename std::iterator_traits<BiIter>::value_type>
  {
  protected:
    BiIter base;
  public:
    typedef typename std::iterator_traits<BiIter>::value_type value_type;
    typedef const value_type& const_reference;
    typedef const value_type* const_pointer;

    proxy_const_iterator (BiIter iter = BiIter())
      : base(iter)
    {
    }

    void 
    assign (BiIter iter)
    {
      base = iter;
    }

    const_reference 
    operator * () const
    {
      return *base;
    }

    const_pointer 
    operator -> () const
    {
      return &*base;
    }

    proxy_const_iterator& 
    operator ++ ()
    {
      ++base;
      return *this;
    }

    proxy_const_iterator 
    operator ++ (int)
    {
      proxy_const_iterator p = *this;
      ++*this;
      return p;
    }

    proxy_const_iterator& 
    operator -- ()
    {
      --base;
      return *this;
    }

    proxy_const_iterator 
    operator -- (int)
    {
      proxy_const_iterator p = *this;
      --*this;
      return p;
    }

    bool 
    operator != (const proxy_const_iterator& rhs) const
    {
      return base != rhs.base;
    }
    bool 
    operator == (const proxy_const_iterator& rhs) const
    {
      return base == rhs.base;
    }
  };
  
  template <typename T>
  class iterator_bridge
  {
    const T* base;
  public:
    typedef const T value_type;

    iterator_bridge ()
      : base(0)
    {
    }

    template <typename Iter>
    iterator_bridge (Iter iter)
      : base(&*iter)
    {
    }

    bool
    operator < (const iterator_bridge& rhs) const
    {
      return *base < *rhs.base;
    }
    
    bool
    operator > (const iterator_bridge& rhs) const
    {
      return rhs < *this;
    }

    bool
    operator <= (const iterator_bridge& rhs) const
    {
      return !(rhs < *this);
    }

    bool
    operator >= (const iterator_bridge& rhs) const
    {
      return !(*this < rhs);
    }

    bool
    operator == (const iterator_bridge& rhs) const
    {
      return *base == *rhs.base;
    }

    bool
    operator != (const iterator_bridge& rhs) const
    {
      return !(*this == rhs);
    }

    value_type&
    ref() const
    {
      return *base;
    }

    template <typename Comp>
    bool 
    compare (const iterator_bridge& rhs, Comp comp) const
    {
      return comp(*base, *rhs.base);
    }
  };

  template <typename T, typename Comp>
  struct proxy_compare: 
    public std::binary_function<iterator_bridge<T>,
				iterator_bridge<T>,
				bool>
  {
    Comp _comp;
    typedef iterator_bridge<T> bridge_type;

    proxy_compare (Comp comp)
      : _comp(comp)
    {
    }

    bool
    operator () (const bridge_type& lhs, 
		 const bridge_type& rhs) const
    {
      return lhs.compare(rhs, _comp);
    }
  };

  template <typename T>
  class proxy_iterator: 
    public std::iterator<std::bidirectional_iterator_tag, T>
  {
  protected:
    typedef proxy_const_iterator<iterator_bridge<T>*> base_iterator;
    base_iterator base;
  public:
    typedef T value_type;
    typedef const value_type& const_reference;
    typedef const value_type* const_pointer;
    
    proxy_iterator (base_iterator iter = 0)
      : base(iter)
    {
    }

    void
    assign (base_iterator iter)
    {
      base = iter;
    }

    const_reference 
    operator * () const
    {
      return base->ref();
    }

    const_pointer 
    operator -> () const
    {
      return &base->ref();
    }

    proxy_iterator& 
    operator ++ ()
    {
      ++base;
      return *this;
    }

    proxy_iterator 
    operator ++ (int)
    {
      proxy_iterator p = *this;
      ++*this;
      return p;
    }

    proxy_iterator& 
    operator -- ()
    {
      --base;
      return *this;
    }

    proxy_iterator 
    operator -- (int)
    {
      proxy_iterator p = *this;
      --*this;
      return p;
    }

    bool 
    operator != (const proxy_iterator& rhs) const
    {
      return base != rhs.base;
    }
    bool 
    operator == (const proxy_iterator& rhs) const
    {
      return base == rhs.base;
    }
  };
}

#endif
