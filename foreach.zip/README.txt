Boost.Foreach is no longer available via the Boost File Vault.
Please get it by downloaded the latest version of Boost.

--
Eric Niebler
BoostPro Computing
www.boostpro.com
