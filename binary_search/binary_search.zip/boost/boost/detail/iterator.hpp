// (C) Copyright David Abrahams 2000. Permission to copy, use, modify,
// sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.

#ifndef ITERATOR_DWA122600_HPP_
# define ITERATOR_DWA122600_HPP_

# include <boost/config.hpp>
# include <boost/type_traits.hpp>
# include <iterator>
# include <cstddef>

namespace boost { namespace detail {
# if !defined(BOOST_NO_STD_ITERATOR_TRAITS) && !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)
using std::iterator_traits;
using std::distance;
# else
// Workarounds for less-capable implementations
template <bool is_ptr> struct iterator_traits_select;
template <> struct iterator_traits_select<true>
{
    template <class Ptr>
    struct traits
    {
        typedef std::ptrdiff_t difference_type;
        typedef std::random_access_iterator_tag iterator_category;
    };
};

template <> struct iterator_traits_select<false>
{
    template <class Iterator>
    struct traits
#  if defined(BOOST_NO_STD_ITERATOR_TRAITS)
    {
#   if defined(BOOST_MSVC) && !defined(__SGI_STL_PORT)
        typedef typename Iterator::distance_type difference_type;
#   else
        typedef typename Iterator::difference_type difference_type;
#   endif
        typedef typename Iterator::iterator_category iterator_category;
    };
#  else
    {
        typedef typename std::iterator_traits<Iterator>::difference_type difference_type;
        typedef typename std::iterator_traits<Iterator>::iterator_category iterator_category;
    };
#  endif
};

template <class Iterator>
struct iterator_traits
{
 private:
    typedef iterator_traits_select<is_pointer<Iterator>::value> select;
    typedef typename select::template traits<Iterator> traits;
 public:
    typedef typename traits::difference_type difference_type;
    typedef typename traits::iterator_category iterator_category;
};

template <class Category>
struct distance_select {
    template <class Iterator>
    static typename ::boost::detail::iterator_traits<Iterator>::difference_type
    distance(Iterator i1, const Iterator i2)
    {
        typename ::boost::detail::iterator_traits<Iterator>::difference_type result = 0;
        while (i1 != i2)
        {
            ++i1;
            ++result;
        }
        return result;
    }
};

template <>
struct distance_select<std::random_access_iterator_tag> {
    template <class Iterator>
    static typename ::boost::detail::iterator_traits<Iterator>::difference_type
    distance(Iterator i1, const Iterator i2)
    {
        return i2 - i1;
    }
};

template <class Iterator>
inline typename ::boost::detail::iterator_traits<Iterator>::difference_type
distance(const Iterator& first, const Iterator& last)
{
    typedef typename ::boost::detail::iterator_traits<Iterator>::iterator_category iterator_category;
    return distance_select<iterator_category>::distance(first, last);
}
# endif // workarounds

}}

#endif // ITERATOR_DWA122600_HPP_
