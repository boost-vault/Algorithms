// Generating All Combinations and Permutations algorithms
// implementation
//
// Copyright (C) 2004 - 2007, BenBear
// benbearchen at gmail dot com
//
// Under boost license

#ifndef __boost_combination_hpp_def
#define __boost_combination_hpp_def

#include <algorithm>

namespace boost
{
  template <typename BiIter>
  inline bool
  next_partial_permutation (BiIter first, BiIter middle, BiIter last)
  {
    if (first == middle)
      return false;

    std::reverse (middle, last);
    return std::next_permutation (first, last);
  }

  template <typename BiIter, typename Comp>
  inline bool
  next_partial_permutation (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    if (first == middle)
      return false;

    std::reverse (middle, last);
    return std::next_permutation (first, last, comp);
  }

  template <typename BiIter>
  inline bool 
  prev_partial_permutation (BiIter first, BiIter middle, BiIter last)
  {
    if (first == middle)
      return false;

    bool ret = std::prev_permutation (first, last);
    std::reverse (middle, last);
    
    return ret;
  }

  template <typename BiIter, typename Comp>
  inline bool 
  prev_partial_permutation (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    if (first == middle)
      return false;

    bool ret = std::prev_permutation (first, last, comp);
    std::reverse (middle, last);

    return ret;
  }

  template <typename BiIter1, typename BiIter2>
  void
  __combination_merge_right (BiIter1 first1, BiIter1 last1,
			     BiIter2 first2, BiIter2 last2)
  {
    if ((first1 == last1) || (first2 == last2))
      return;

    BiIter1 m1 = last1;
    BiIter2 m2 = first2;
    while ((m1 != first1) && (m2 != last2))
      std::iter_swap (--m1, m2++);

    std::reverse (first1, m1);
    std::reverse (first1, last1);

    std::reverse (m2, last2);
    std::reverse (first2, last2);
  }

  template <typename BiIter>
  bool
  __do_next_combination (BiIter first1, BiIter last1, 
			 BiIter first2, BiIter last2)
  {
    if ((first1 == last1) || (first2 == last2))
      return false;

    BiIter qmax = last2;
    --qmax;
    BiIter pout1 = std::lower_bound(first1, last1, *qmax);
    bool fin = pout1 == first1;
    BiIter left1, left2;
    if (!fin)
      {
	BiIter pout = pout1;
	--pout;
	BiIter qin = std::upper_bound(first2, last2, *pout);
	std::iter_swap (pout, qin);
	left1 = pout;
	++left1;
	left2 = qin;
	++left2;
      }
    else
      {
	left1 = first1;
	left2 = first2;
      }
    __combination_merge_right (left1, last1, left2, last2);
    return !fin;
  }

  template <typename BiIter, typename Comp>
  bool
  __do_next_combination (BiIter first1, BiIter last1, 
			 BiIter first2, BiIter last2,
			 Comp comp)
  {
    if ((first1 == last1) || (first2 == last2))
      return false;

    BiIter qmax = last2;
    --qmax;
    BiIter pout1 = std::lower_bound(first1, last1, *qmax, comp);
    bool fin = pout1 == first1;
    BiIter left1, left2;
    if (!fin)
      {
	BiIter pout = pout1;
	--pout;
	BiIter qin = std::upper_bound(first2, last2, *pout, comp);
	std::iter_swap (pout, qin);
	left1 = pout;
	++left1;
	left2 = qin;
	++left2;
      }
    else
      {
	left1 = first1;
	left2 = first2;
      }
    __combination_merge_right (left1, last1, left2, last2);
    return !fin;
  }

  template <typename BiIter>
  inline bool
  next_combination (BiIter first, BiIter middle, BiIter last)
  {
    return __do_next_combination (first, middle, middle, last);
  }

  template <typename BiIter, typename Comp>
  inline bool
  next_combination (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    return __do_next_combination (first, middle, 
				  middle, last, 
				  comp);
  }

  template <typename BiIter>
  inline bool 
  prev_combination (BiIter first, BiIter middle, BiIter last)
  {
    return __do_next_combination (middle, last, first, middle);
  }

  template <typename BiIter, typename Comp>
  inline bool 
  prev_combination (BiIter first, BiIter middle, BiIter last, 
		    Comp comp)
  {
    return __do_next_combination (middle, last, 
				  first, middle, 
				  comp);
  }
}

#endif
