#include "combination.hpp"
using namespace boost;

#include <algorithm>
using namespace std;

#include <iostream>

template <typename Iter>
void
visit (Iter first, Iter last)
{
  for (Iter i = first; i != last; ++i)
    cout << *i << " ";
  cout << endl;
}

template <typename BiIter>
void
example_of_partial_permutation (BiIter first, BiIter middle, BiIter last)
{
  // only thing you must do before calling partial_permutation:
  // sort(middle, last)

  // ok, the initialization is: 
  // sort (middle, last)

  //////////////////////////////////////////////////////////
  // 1. start at input range

  // initialization
  sort (middle, last);		// the only thing :-)

  // now, you can visit the result, it's valid from here.
  visit (first, middle);

  // we go to greatest
  do
    {
      visit (first, middle);
    }
  while (next_partial_permutation (first, middle, last));

  cout << "-------------------";
  cin.get();


  //////////////////////////////////////////////////////////
  // 2. start from any input range
  random_shuffle (first, last);	// destroy it :-(

  // initialization
  sort (middle, last);		// yeah, it live now.
  // visit (first, middle);

  // if ... I just like do 20 times `prev', not care the terminus
  for (int i = 0; i < 20; ++i)
    {
      visit (first, middle);
      prev_partial_permutation (first, middle, last);
    }

  cout << "-------------------";
  cin.get();


  ///////////////////////////////////////////////////////////
  // 3. from the smallest to greatest

  // place the smallest elements in [first, middle), and the greatest
  // in [middle, last), all sorted.  Luckly, one sort do this.
  sort (first, last);		// this make it smallest
  
  // go through
  do
    {
      visit (first, middle);
    }
  while (next_partial_permutation (first, middle, last));

  cout << "-------------------";
  cin.get();


  ////////////////////////////////////////////////////////////
  // 4. from the greatest to smallest

  // place the greatest elements in [first, middle), REVERSE sorted,
  // and the smallest in [middle, last), sorted.

  // initialization
  // Method 1
  sort (first, last);
  reverse (first, last);
  reverse (middle, last);
  // Method 2, actually, previous of the smallest is the greatest!!
  sort (first, last);				  // smallest, now
  prev_partial_permutation (first, middle, last); // bomb :-), greatest now

  // go through
  do
    {
      visit (first, middle);
    }
  while (prev_partial_permutation (first, middle, last));

  cout << "-------------------";
  cin.get();
}

template <typename BiIter>
void
example_of_combination (BiIter first, BiIter middle, BiIter last)
{
  // two things you should do before calling combination:
  // sort(first, middle) and sort(middle, last)

  // ok, the initialization is: 
  // sort (first, middle)
  // sort (middle, last)

  //////////////////////////////////////////////////////////
  // 1. start at input range

  // initialization
  sort (first, middle);
  sort (middle, last);

  // now, you can visit the result, it's valid from here.
  visit (first, middle);

  // we go to greatest
  do
    {
      visit (first, middle);
    }
  while (next_combination (first, middle, last));

  cout << "-------------------";
  cin.get();


  //////////////////////////////////////////////////////////
  // 2. start from any input range
  random_shuffle (first, last);	// destroy it :-(

  // initialization
  sort (first, middle);
  sort (middle, last);		// yeah, it live now.
  // visit (first, middle);

  // if ... I just like do 20 times dance, not care the terminus
  for (int i = 0; i < 20; ++i)
    {
      visit (first, middle);
      prev_combination (first, middle, last);
      next_combination (first, middle, last);
      next_combination (first, middle, last);
    }

  cout << "-------------------";
  cin.get();


  ///////////////////////////////////////////////////////////
  // 3. from the smallest to greatest

  // place the smallest elements in [first, middle), and the greatest
  // in [middle, last), all sorted.  Luckly, one sort do this.
  sort (first, last);		// this make it smallest
  
  // go through
  do
    {
      visit (first, middle);
    }
  while (next_combination (first, middle, last));

  cout << "-------------------";
  cin.get();


  ////////////////////////////////////////////////////////////
  // 4. from the greatest to smallest

  // place the greatest elements in [first, middle), sorted, and the
  // smallest in [middle, last), sorted.

  // initialization
  // Method 1
  sort (first, last);
  reverse (first, last);
  reverse (first, middle);
  reverse (middle, last);
  // Method 2, actually, previous of the smallest is the greatest!!
  sort (first, last);			  // smallest, now
  prev_combination (first, middle, last); // bomb :-), greatest now

  // go through
  do
    {
      visit (first, middle);
    }
  while (prev_combination (first, middle, last));

  cout << "-------------------";
  cin.get();
}

int main ()
{
  int a[5] = {0, 1, 2, 3, 4};

  example_of_partial_permutation (a, a + 2, a + 5);

  example_of_combination (a, a + 3, a + 5);
}
