#include "combination.hpp"
using namespace boost;

#include <algorithm>
#include <iterator>
#include <vector>
#include <iostream>
#include <functional>
using namespace std;

template <typename Iter>
bool
test_sequence_grow (Iter first, Iter last)
{
  if (first == last)
    return true;

  for (Iter a = first, b = first; ++b != last; ++a)
    {
      if (*b < *a)
	return false;
    }
  return true;
}

template <typename Iter, typename Comp>
bool
test_sequence_grow (Iter first, Iter last, Comp comp)
{
  if (first == last)
    return true;

  for (Iter a = first, b = first; ++b != last; ++a)
    {
      if (comp (*b, *a))
	return false;
    }
  return true;
}

template <typename Iter1, typename Iter2>
bool
test_two_sequence_less (Iter1 first1, Iter1 last1,
			Iter2 first2, Iter2 last2)
{
  for (; (first1 != last1) && (first2 != last2); ++first1, ++first2)
    if (*first2 < *first1)
      return false;
    else if (*first1 < *first2)
      return true;

  if (first1 != last1)
    return false;
  else if (first2 != last2)
    return true;

  return false;
}

template <typename Iter1, typename Iter2, typename Comp>
bool
test_two_sequence_less (Iter1 first1, Iter1 last1,
			Iter2 first2, Iter2 last2,
			Comp comp)
{
  for (; (first1 != last1) && (first2 != last2); ++first1, ++first2)
    if (comp (*first2, *first1))
      return false;
    else if (comp (*first1, *first2))
      return true;

  if (first1 != last1)
    return false;
  else if (first2 != last2)
    return true;

  return false;
}

template <typename RandomIter>
int
test_get_combi_count (RandomIter first, RandomIter middle, RandomIter last)
{
  if (first == middle)
    return 0;

  sort (first, last);
  
  int count = 0;
  do
    {
      if (test_sequence_grow (first, middle))
	++count;
    }
  while (next_partial_permutation (first, middle, last));

  return count;
}

// warning: sequence1 < sequence2 may be differenct with sequence2 > sequence1
//          because sequence1's comp object may be differenct with sequence2's
template <typename Iter, 
	  typename Comp = std::less<typename std::iterator_traits<Iter>::value_type> >
class sequence
{
  typedef typename iterator_traits<Iter>::value_type value_type;

  vector<value_type> values;

  Comp compare;
public:
  typedef typename vector<value_type>::const_iterator iterator;
  
  explicit
  sequence (Comp comp = Comp())
    : compare(comp)
  {
  }

  template <typename Iter2>
  sequence (Iter2 begin, Iter2 end, Comp comp = Comp())
    : values(begin, end), compare(comp)
  {
  }

  template <typename Iter2, typename Comp2>
  sequence&
  operator = (const sequence<Iter2, Comp2>& seq)
  {
    values.assign (seq.begin(), seq.end());
    return *this;
  }

  template <typename Iter2>
  void
  assign (Iter2 begin, Iter2 end)
  {
    values.assign (begin, end);
  }
  
  template <typename Iter2, typename Comp2>
  bool
  operator == (const sequence<Iter2, Comp2>& seq) const
  {
    return (!(*this < seq) && !(seq < *this));
  }
  
  template <typename Iter2, typename Comp2>
  bool
  operator != (const sequence<Iter2, Comp2>& seq) const
  {
    return !(*this == seq);
  }
  
  template <typename Iter2, typename Comp2>
  bool
  operator < (const sequence<Iter2, Comp2>& seq) const
  {
    return test_two_sequence_less (begin(), end(),
				   seq.begin(), seq.end(), 
				   compare);
  }
  template <typename Iter2, typename Comp2>
  bool
  operator > (const sequence<Iter2, Comp2>& seq) const
  {
    return test_two_sequence_less (seq.begin(), seq.end(),
				   begin(), end(),
				   compare);
  }
  template <typename Iter2, typename Comp2>
  bool
  operator <= (const sequence<Iter2, Comp2>& seq) const
  {
    return !(*this > seq);
  }

  template <typename Iter2, typename Comp2>
  bool
  operator >= (const sequence<Iter2, Comp2>& seq) const
  {
    return !(*this < seq);
  }

  iterator
  begin() const
  {
    return values.begin();
  }

  iterator
  end() const
  {
    return values.end();
  }

  void
  clear ()
  {
    values.clear ();
  }

  void
  out () const
  {
    for (iterator i = begin(); i != end(); ++i)
      cout << *i << " ";
    cout << endl;
  }
};

template <typename BiIter>
bool
test_combi_with_partial_permutation (BiIter first, BiIter middle, BiIter last)
{
  typedef typename iterator_traits<BiIter>::value_type value_type;
  ptrdiff_t r = distance (first, middle);
  vector<value_type> vc(first, last);
  vector<value_type> vp(first, last);

  typedef sequence<typename vector<value_type>::iterator> seq;
  vector<seq> stack;

  sort (vc.begin(), vc.end());
  sort (vp.begin(), vp.end());

  bool finish1, finish2;
  do
    {
      seq seq1(vc.begin(), vc.begin() + r);
      seq seq2(vp.begin(), vp.begin() + r);

      if (seq1 != seq2)
	{
	  seq1.out ();
	  seq2.out ();
	  throw "don't equal while next of combi and permu";
	}

      stack.push_back (seq1);

      finish1 = next_combination (vc.begin(), vc.begin() + r, vc.end());
      do
	{
	  finish2 = next_partial_permutation (vp.begin(), vp.begin() + r, 
					      vp.end());
	}
      while (finish2 && !test_sequence_grow (vp.begin(), vp.begin() + r));
    }
  while (finish1 && finish2);

  if (finish1 != finish2)
    {
      throw "the times of combi and permu next are not same";
    }

  sort (vc.begin(), vc.end());
  prev_combination (vc.begin(), vc.begin() + r, vc.end());
  copy (vc.begin(), vc.end(), vp.begin());

  do
    {
      seq seq1(vc.begin(), vc.begin() + r);
      seq seq2(vp.begin(), vp.begin() + r);

      if (seq1 != seq2)
	{
	  seq1.out ();
	  seq2.out ();
	  throw "don't equal while prev of combi and permu";
	}

      if (stack.empty())
	{
	  throw "prev is longer than next";
	}
      if (seq1 != stack.back())
	{
	  seq1.out ();
	  stack.back().out ();
	  throw "prev is not equal next";
	}

      stack.pop_back ();

      finish1 = prev_combination (vc.begin(), vc.begin() + r, vc.end());

      do
	{
	  finish2 = prev_partial_permutation (vp.begin(), vp.begin() + r,
					      vp.end());
	}
      while (finish2 && !test_sequence_grow (vp.begin(), vp.begin() + r));
    }
  while (finish1 && finish2);

  if (finish1 != finish2)
    {
      throw "the times of combi and permu'prev are not same";
    }

  if (!stack.empty())
    {
      throw "next is longer than prev";
    }

  return true;
}

int main ()
{
  try
    {
      const int N = 5;
      int a[N];
      for (int i = 0; i < N; ++i)
	for (int j = i; j < N; ++j)
	  for (int k = j; k < N; ++k)
	    for (int l = j; k < N; ++k)
	      for (int m = j; k < N; ++k)
		{
		  a[0] = i;
		  a[1] = j;
		  a[2] = k;
		  a[3] = l;
		  a[4] = m;
		  
		  for (int z = 0; z < N; ++z)
		    test_combi_with_partial_permutation (a, a + z, a + N);
		}
      cout << "ok" << endl;
    }
  catch (const char* err)
    {
      cout << "failed: " << err << endl;
    }
}
