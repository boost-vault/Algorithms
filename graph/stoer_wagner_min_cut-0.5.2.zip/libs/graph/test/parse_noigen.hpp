//            Copyright Daniel Trebbien 2010.
// Distributed under the Boost Software License, Version 1.0.
//   (See accompanying file LICENSE_1_0.txt or the copy at
//         http://www.boost.org/LICENSE_1_0.txt)

#ifndef PARSE_NOIGEN_HPP
#define PARSE_NOIGEN_HPP 1
#include <cassert>
#include <iostream>
#include <vector>

namespace detail {

struct edge_t
{
  unsigned long first;
  unsigned long second;
};

} // end `namespace detail`

template <class UndirectedGraph, typename WeightT>
inline UndirectedGraph parse_noigen(std::istream& is)
{
  long n = -1, m = -1;
  std::vector<detail::edge_t> edges;
  std::vector<WeightT> ws;
  while (is) {
    char l;
    if (is >> std::skipws >> l) {
      if (l == 'c') { // comment line
        char trash[32];
        while (is.getline(trash, 32).rdstate() & std::ios::failbit)
          is.clear(is.rdstate() & ~std::ios::failbit);
      } else if (l == 'p') {
        assert(n < 0 && m < 0);
        
        std::string word;
        if (is >> std::skipws >> word) {
          assert(word == "cut");
          is >> n >> m;
        }
      } else if (l == 'a') {
        detail::edge_t e = {0, 0};
        WeightT w;
        if (is >> e.first >> e.second >> w) {
          --e.first; --e.second; // vertex indices in NOIGEN format start at 1
          assert(static_cast<unsigned long>(n) > e.first && e.first >= 0);
          assert(static_cast<unsigned long>(n) > e.second && e.second >= 0);
          edges.push_back(e);
          ws.push_back(w);
        }
      }
    }
  }
  
  assert(edges.size() == ws.size());
  assert(edges.size() == static_cast<std::vector<detail::edge_t>::size_type>(m));
  
  return UndirectedGraph(edges.begin(), edges.end(), ws.begin(), n, m);
}

#endif // !PARSE_NOIGEN_HPP
