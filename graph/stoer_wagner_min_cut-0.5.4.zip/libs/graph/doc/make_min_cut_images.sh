#! /usr/bin/env sh

fdp -s -n -Tgif -odigraph1.gif digraph1.dot
fdp -s -n -Tgif -odigraph1-min-cut.gif digraph1-min-cut.dot
fdp -s -n -Tgif -ostoer_wagner-example.gif stoer_wagner-example.dot
fdp -s -n -Tgif -ostoer_wagner-example-c1.gif stoer_wagner-example-c1.dot
fdp -s -n -Tgif -ostoer_wagner-example-min-cut.gif stoer_wagner-example-min-cut.dot
dot -Tgif -ostoer_wagner.cpp.gif stoer_wagner.cpp.dot
