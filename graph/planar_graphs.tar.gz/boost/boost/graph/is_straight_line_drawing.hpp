//=======================================================================
// Copyright 2007 Aaron Windsor
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//=======================================================================
#ifndef __IS_STRAIGHT_LINE_DRAWING_HPP__
#define __IS_STRAIGHT_LINE_DRAWING_HPP__

#include <boost/config.hpp>
#include <boost/utility.hpp> //for next and prior
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_comparison.hpp>
#include <boost/property_map.hpp>
#include <boost/graph/properties.hpp>

#include <algorithm>
#include <vector>
#include <set>

#include <boost/graph/planar_detail/bucket_sort.hpp>


namespace boost
{

  bool intersects(double x1, double y1,
		  double x2, double y2,
		  double a1, double b1,
		  double a2, double b2,
		  double epsilon = 0.000001
		  )
  {

    if (x1 - x2 == 0)
      {
	std::swap(x1,a1);
	std::swap(y1,b1);
	std::swap(x2,a2);
	std::swap(y2,b2);
      }

    if (x1 - x2 == 0)
      {
	//two vertical line segments
	double min_y = std::min(y1,y2);
	double max_y = std::max(y1,y2);
	double min_b = std::min(b1,b2);
	double max_b = std::max(b1,b2);
	if ((max_y > max_b && max_b > min_y) ||
	    (max_b > max_y && max_y > min_b)
	    )
	  return true;
	else
	  return false;
      }

    double x_diff = x1 - x2;
    double y_diff = y1 - y2;
    double a_diff = a2 - a1;
    double b_diff = b2 - b1;

    double beta_denominator = b_diff - (y_diff/((double)x_diff)) * a_diff;

    if (beta_denominator == 0)
      {
	//parallel lines
	return false;
      }

    double beta = (b2 - y2 - (y_diff/((double)x_diff)) * (a2 - x2)) / 
      beta_denominator;
    double alpha = (a2 - x2 - beta*(a_diff))/x_diff;

    double upper_bound = 1 - epsilon;
    double lower_bound = 0 + epsilon;

    return (beta < upper_bound && beta > lower_bound && 
	    alpha < upper_bound && alpha > lower_bound);

  }


  template <typename Graph, typename GridPositionMap, typename VertexIndexMap>
  bool is_straight_line_drawing(const Graph& g, 
				GridPositionMap drawing, 
				VertexIndexMap vm
				)
  {
    //assume: no parallel edges between a pair of vertices

    typedef typename graph_traits<Graph>::vertex_descriptor vertex_t;
    typedef typename graph_traits<Graph>::vertex_iterator vertex_iterator_t;
    typedef typename graph_traits<Graph>::edge_descriptor edge_t;
    typedef typename graph_traits<Graph>::edge_iterator edge_iterator_t;
    typedef typename graph_traits<Graph>::edges_size_type e_size_t;
    typedef typename graph_traits<Graph>::vertices_size_type v_size_t;

    typedef typename GridPositionMap::value_type coord_t;
    typedef std::size_t x_coord_t;
    typedef std::size_t y_coord_t;
    typedef boost::tuple<edge_t, x_coord_t, y_coord_t> edge_event_t;
    typedef typename std::vector< edge_event_t > edge_event_queue_t;

    typedef tuple<y_coord_t, y_coord_t, x_coord_t, x_coord_t> active_map_key_t;
    typedef edge_t active_map_value_t;
    typedef std::map< active_map_key_t, active_map_value_t > active_map_t;
    typedef typename active_map_t::iterator active_map_iterator_t;


    edge_event_queue_t edge_event_queue;
    active_map_t active_edges;

    edge_iterator_t ei, ei_end;
    for(tie(ei,ei_end) = edges(g); ei != ei_end; ++ei)
      {
	edge_t e(*ei);
	coord_t source_coord(get(drawing, source(e,g)));
	coord_t target_coord(get(drawing, target(e,g)));
	edge_event_queue.push_back
	  (make_tuple(e,source_coord.x,source_coord.y)); 
	edge_event_queue.push_back
	  (make_tuple(e,target_coord.x,target_coord.y)); 
      }

    // Order by edge_event_queue by first, then second coordinate 
    // (bucket_sort is a stable sort.)
    bucket_sort(edge_event_queue.begin(), edge_event_queue.end(),
		property_map_tuple_adaptor<edge_event_t, 2>()
		);
    
    bucket_sort(edge_event_queue.begin(), edge_event_queue.end(),
		property_map_tuple_adaptor<edge_event_t, 1>()
		);

    typedef typename edge_event_queue_t::iterator event_queue_iterator_t;
    event_queue_iterator_t itr_end = edge_event_queue.end();
    for(event_queue_iterator_t itr = edge_event_queue.begin(); 
	itr != itr_end; ++itr
	)
      {
	edge_t e(get<0>(*itr));
	vertex_t source_v = source(e,g);
	vertex_t target_v = target(e,g);
	if (get(drawing, source_v).x > get(drawing, target_v).x)
	  std::swap(source_v, target_v);

	active_map_key_t key(get(drawing, source_v).y,
			     get(drawing, target_v).y,
			     get(drawing, source_v).x,
			     get(drawing, target_v).x
			     );
	active_map_iterator_t a_itr = active_edges.find(key);
	if (a_itr == active_edges.end())
	  {
	    active_edges[key] = e;
	  }
	else
	  {
	    active_map_iterator_t before, after;
	    if (a_itr == active_edges.begin())
	      before = active_edges.end();
	    else
	      before = prior(a_itr);
	    after = next(a_itr);

	    if (after != active_edges.end() || before != active_edges.end())
	      {
		
		edge_t f = after != active_edges.end() ? 
		  after->second : before->second;

		if (intersects(get(drawing, source(e,g)).x, 
			       get(drawing, source(e,g)).y,
			       get(drawing, target(e,g)).x, 
			       get(drawing, target(e,g)).y,
			       get(drawing, source(f,g)).x, 
			       get(drawing, source(f,g)).y,
			       get(drawing, target(f,g)).x, 
			       get(drawing, target(f,g)).y
			       )
		    )
		  return false;
	      }

	    active_edges.erase(a_itr);

	  }
      }

    return true;
    
  }


  template <typename Graph, typename GridPositionMap>
  bool is_straight_line_drawing(const Graph& g, GridPositionMap drawing)
  {
    return is_straight_line_drawing(g, drawing, get(vertex_index,g));
  }

}

#endif // __IS_STRAIGHT_LINE_DRAWING_HPP__
